export {Lib as LibModule} from './lib/index';
export {App as LibAppModule} from './app/index';

export * from './app/routes/home.route';
