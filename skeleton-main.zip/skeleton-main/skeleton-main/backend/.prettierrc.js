module.exports = {
  ...require('gts/.prettierrc.json')
}
