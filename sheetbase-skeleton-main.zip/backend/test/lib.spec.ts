import {describe, it} from 'mocha';
import {expect} from 'chai';

describe('Lib', () => {
  it('TODO: add tests!', () => {
    expect(true).equal(true);
  });
});
