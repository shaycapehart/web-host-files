import {App} from './app/index';

export const www = new App().getApp();
