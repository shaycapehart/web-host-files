
export class Lib {

  constructor() {
  }

}
