# Sheetbase Module: backend

undefined

## Install

Using npm: `npm install --save backend`

```ts
import * as App from "backend";
```

As a library: `1cOCLWaUbxdnpJDCYMgTfMMUUJBPyj__JRn5X-RvUjZz4SACew02uyZO7`

Set the _Indentifier_ to **AppModule** and select the lastest version, [view code](https://script.google.com/d/1cOCLWaUbxdnpJDCYMgTfMMUUJBPyj__JRn5X-RvUjZz4SACew02uyZO7/edit?usp=sharing).

```ts
declare const AppModule: { App: any };
const App = AppModule.App;
```

## Usage

- Homepage: undefined

## License

**backend** is released under the [undefined](undefined/blob/master/LICENSE) license.
