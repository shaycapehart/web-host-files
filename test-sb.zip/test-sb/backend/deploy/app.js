(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
    typeof define === 'function' && define.amd ? define(['exports'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global.App = {}));
})(this, (function (exports) { 'use strict';

    var __assign$6 = function () {
        __assign$6 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$6.apply(this, arguments);
    };
    var OptionService = /** @class */ (function () {
        function OptionService(options) {
            if (options === void 0) { options = {}; }
            this.options = __assign$6({ allowMethodsWhenDoGet: false, views: '', disabledRoutes: [], routingErrors: {} }, options);
        }
        OptionService.prototype.get = function (key) {
            if (key === void 0) { key = null; }
            if (key) {
                return this.options[key];
            }
            return this.options;
        };
        OptionService.prototype.set = function (dataOrKey, value) {
            if (value === void 0) { value = null; }
            if (dataOrKey instanceof Object) {
                var data = dataOrKey;
                this.options = __assign$6({}, this.options, data);
            }
            else {
                var key = dataOrKey;
                this.options[key] = value;
            }
            return this.options;
        };
        OptionService.prototype.getAllowMethodsWhenDoGet = function () {
            return this.options.allowMethodsWhenDoGet;
        };
        OptionService.prototype.setAllowMethodsWhenDoGet = function (value) {
            this.options.allowMethodsWhenDoGet = value;
        };
        OptionService.prototype.getViews = function () {
            return this.options.views;
        };
        OptionService.prototype.setViews = function (value) {
            this.options.views = value;
        };
        OptionService.prototype.getDisabledRoutes = function () {
            return this.options.disabledRoutes;
        };
        OptionService.prototype.setDisabledRoutes = function (value, override) {
            if (override === void 0) { override = false; }
            if (override) {
                this.options.disabledRoutes = value;
            }
            else {
                this.options.disabledRoutes = this.options.disabledRoutes.concat(value);
            }
        };
        OptionService.prototype.getRoutingErrors = function () {
            return this.options.routingErrors;
        };
        OptionService.prototype.setRoutingErrors = function (value, override) {
            if (override === void 0) { override = false; }
            if (override) {
                this.options.routingErrors = value;
            }
            else {
                this.options.routingErrors = __assign$6({}, this.options.routingErrors, value);
            }
        };
        return OptionService;
    }());

    var __assign$1$3 = function () {
        __assign$1$3 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$1$3.apply(this, arguments);
    };
    var HttpService = /** @class */ (function () {
        function HttpService(optionService, responseService, routerService) {
            this.allowedMethods = [
                'GET', 'POST', 'PUT', 'PATCH', 'DELETE',
            ];
            this.optionService = optionService;
            this.responseService = responseService;
            this.routerService = routerService;
        }
        HttpService.prototype.get = function (e) {
            return this.http(e, 'GET');
        };
        HttpService.prototype.post = function (e) {
            return this.http(e, 'POST');
        };
        HttpService.prototype.http = function (e, method) {
            if (method === void 0) { method = 'GET'; }
            var endpoint = (e.parameter || {}).e || '';
            if (endpoint.substr(0, 1) !== '/') {
                endpoint = '/' + endpoint;
            }
            // methods
            var originalMethod = method;
            var allowMethodsWhenDoGet = this.optionService.get('allowMethodsWhenDoGet');
            if (method !== 'GET' || (method === 'GET' && allowMethodsWhenDoGet)) {
                var useMeMethod = (e.parameter || {}).method;
                method = useMeMethod ? useMeMethod.toUpperCase() : method;
                method = (this.allowedMethods.indexOf(method) < 0) ? originalMethod : method;
            }
            // request object
            var req = {
                query: e.parameter || {},
                params: e.parameter || {},
                body: {},
                data: {}
            };
            // body
            if (method === 'GET' && allowMethodsWhenDoGet) {
                try {
                    req.body = JSON.parse((e.parameter || {}).body || '{}');
                }
                catch (error) {
                    req.body = {};
                }
            }
            else {
                req.body = JSON.parse(e.postData ? e.postData.contents : '{}');
            }
            // response object
            var res = this.responseService;
            // execute handlers
            var handlers = this.routerService.route(method, endpoint);
            return this.execute(handlers, req, res);
        };
        HttpService.prototype.execute = function (handlers, req, res) {
            var _this = this;
            var handler = handlers.shift();
            if (!handler) {
                throw new Error('Invalid router handler!');
            }
            if (handlers.length < 1) {
                return handler(req, res);
            }
            else {
                var next = function (data) {
                    if (data) {
                        if (!(data instanceof Object)) {
                            data = { value: data };
                        }
                        req.data = __assign$1$3({}, (req.data || {}), (data || {}));
                    }
                    return _this.execute(handlers, req, res);
                };
                return handler(req, res, next);
            }
        };
        return HttpService;
    }());

    var RequestService = /** @class */ (function () {
        function RequestService() {
        }
        RequestService.prototype.query = function (e) {
            if (e === void 0) { e = {}; }
            return this.params(e);
        };
        RequestService.prototype.params = function (e) {
            if (e === void 0) { e = {}; }
            return (e.parameter ? e.parameter : {});
        };
        RequestService.prototype.body = function (e) {
            if (e === void 0) { e = {}; }
            var body = {};
            try {
                body = JSON.parse((e.postData && e.postData.contents) ? e.postData.contents : '{}');
            }
            catch (error) {
                /* */
            }
            return body;
        };
        return RequestService;
    }());

    var __assign$2$2 = function () {
        __assign$2$2 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$2$2.apply(this, arguments);
    };
    var ResponseService = /** @class */ (function () {
        function ResponseService(optionService) {
            this.allowedExtensions = [
                'gs', 'hbs', 'ejs',
            ];
            this.optionService = optionService;
        }
        ResponseService.prototype.setErrors = function (errors, override) {
            if (override === void 0) { override = false; }
            this.optionService.setRoutingErrors(errors, override);
        };
        ResponseService.prototype.send = function (content) {
            if (content instanceof Object)
                return this.json(content);
            return this.html(content);
        };
        ResponseService.prototype.html = function (html) {
            return HtmlService.createHtmlOutput(html);
        };
        ResponseService.prototype.render = function (template, data, viewEngine) {
            if (data === void 0) { data = {}; }
            if (viewEngine === void 0) { viewEngine = 'raw'; }
            if (typeof template === 'string') {
                var fileName = template;
                var views = this.optionService.get('views');
                var fileExt = template.split('.').pop();
                fileExt = (this.allowedExtensions.indexOf(fileExt) > -1) ? fileExt : null;
                if (fileExt) {
                    viewEngine = fileExt;
                }
                template = HtmlService.createTemplateFromFile((views ? views + '/' : '') + fileName);
            }
            // render accordingly
            var templateText = template.getRawContent();
            var outputHtml;
            if (viewEngine === 'native' || viewEngine === 'gs') {
                try {
                    for (var _i = 0, _a = Object.keys(data); _i < _a.length; _i++) {
                        var key = _a[_i];
                        template[key] = data[key];
                    }
                    // NOTE: somehow this doesn't work
                    outputHtml = template.evaluate().getContent();
                }
                catch (error) {
                    outputHtml = templateText;
                }
            }
            else if (viewEngine === 'handlebars' || viewEngine === 'hbs') {
                var render = Handlebars.compile(templateText);
                outputHtml = render(data);
            }
            else if (viewEngine === 'ejs') {
                outputHtml = ejs.render(templateText, data);
            }
            else {
                outputHtml = templateText;
            }
            return this.html(outputHtml);
        };
        ResponseService.prototype.json = function (object) {
            var JSONString = JSON.stringify(object);
            var JSONOutput = ContentService.createTextOutput(JSONString);
            JSONOutput.setMimeType(ContentService.MimeType.JSON);
            return JSONOutput;
        };
        ResponseService.prototype.success = function (data, meta) {
            if (meta === void 0) { meta = {}; }
            if (!data)
                return this.error();
            if (!(data instanceof Object)) {
                data = { value: data };
            }
            if (!(meta instanceof Object)) {
                meta = { value: meta };
            }
            var success = {
                success: true,
                status: 200,
                data: data,
                meta: __assign$2$2({ at: (new Date()).getTime() }, meta)
            };
            return this.json(success);
        };
        ResponseService.prototype.error = function (err, meta) {
            if (meta === void 0) { meta = {}; }
            var responseError;
            if (typeof err === 'string') { // a string
                // build response erro from routing errors
                var code = err;
                var errors = this.optionService.getRoutingErrors();
                var error = errors[code];
                if (!error) {
                    error = { message: code };
                    code = null;
                }
                else {
                    error = (typeof error === 'string') ? { status: 400, message: error } : error;
                }
                // return a response error
                var _a = error, _b = _a.status, status = _b === void 0 ? 400 : _b, message = _a.message;
                responseError = { code: code, message: message, status: status };
            }
            else { // a ResponseError
                responseError = err || {};
            }
            if (!responseError.status)
                responseError.status = 500;
            if (!responseError.code)
                responseError.code = 'app/internal';
            if (!responseError.message)
                responseError.message = 'Unknown error.';
            if (!(meta instanceof Object)) {
                meta = { value: meta };
            }
            return this.json(__assign$2$2({}, responseError, { error: true, meta: __assign$2$2({ at: (new Date()).getTime() }, meta) }));
        };
        return ResponseService;
    }());

    var RouterService = /** @class */ (function () {
        function RouterService(optionService) {
            this.routes = {};
            this.sharedMiddlewares = [];
            this.routeMiddlewares = {};
            this.optionService = optionService;
        }
        RouterService.prototype.setErrors = function (errors, override) {
            if (override === void 0) { override = false; }
            this.optionService.setRoutingErrors(errors, override);
        };
        RouterService.prototype.setDisabled = function (disabledRoutes, override) {
            if (override === void 0) { override = false; }
            this.optionService.setDisabledRoutes(disabledRoutes, override);
        };
        RouterService.prototype.use = function () {
            var handlers = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                handlers[_i] = arguments[_i];
            }
            if (typeof handlers[0] === 'string') {
                var routeName = handlers.shift();
                this.routeMiddlewares['GET:' + routeName] = handlers;
                this.routeMiddlewares['POST:' + routeName] = handlers;
                this.routeMiddlewares['PUT:' + routeName] = handlers;
                this.routeMiddlewares['PATCH:' + routeName] = handlers;
                this.routeMiddlewares['DELETE:' + routeName] = handlers;
            }
            else {
                this.sharedMiddlewares = this.sharedMiddlewares.concat(handlers);
            }
        };
        RouterService.prototype.all = function (routeName) {
            var handlers = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                handlers[_i - 1] = arguments[_i];
            }
            this.register.apply(this, ['ALL', routeName].concat(handlers));
        };
        RouterService.prototype.get = function (routeName) {
            var handlers = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                handlers[_i - 1] = arguments[_i];
            }
            this.register.apply(this, ['GET', routeName].concat(handlers));
        };
        RouterService.prototype.post = function (routeName) {
            var handlers = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                handlers[_i - 1] = arguments[_i];
            }
            this.register.apply(this, ['POST', routeName].concat(handlers));
        };
        RouterService.prototype.put = function (routeName) {
            var handlers = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                handlers[_i - 1] = arguments[_i];
            }
            this.register.apply(this, ['PUT', routeName].concat(handlers));
        };
        RouterService.prototype.patch = function (routeName) {
            var handlers = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                handlers[_i - 1] = arguments[_i];
            }
            this.register.apply(this, ['PATCH', routeName].concat(handlers));
        };
        RouterService.prototype["delete"] = function (routeName) {
            var handlers = [];
            for (var _i = 1; _i < arguments.length; _i++) {
                handlers[_i - 1] = arguments[_i];
            }
            this.register.apply(this, ['DELETE', routeName].concat(handlers));
        };
        RouterService.prototype.route = function (method, routeName) {
            var notFoundHandler = function (req, res) {
                try {
                    return res.render('errors/404');
                }
                catch (error) {
                    return res.html("\n\t\t\t\t\t<h1>404!</h1>\n\t\t\t\t\t<p>Not found.</p>\n\t\t\t\t");
                }
            };
            // check if route is disabled
            if (this.disabled(method, routeName)) {
                return [notFoundHandler];
            }
            var handler = this.routes[method + ':' + routeName] || notFoundHandler;
            var handlers = this.routeMiddlewares[method + ':' + routeName] || [];
            // shared middlewares
            handlers = this.sharedMiddlewares.concat(handlers);
            // main handler
            handlers.push(handler);
            return handlers;
        };
        RouterService.prototype.register = function (method, routeName) {
            var handlers = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                handlers[_i - 2] = arguments[_i];
            }
            // remove invalid handlers
            for (var i = 0; i < handlers.length; i++) {
                if (!handlers[i] || (i !== 0 && !(handlers[i] instanceof Function))) {
                    handlers.splice(i, 1);
                }
            }
            // register
            method = method || 'ALL';
            var handler = handlers.pop();
            if (method === 'ALL' || method === 'GET') {
                this.routes['GET:' + routeName] = handler;
                this.routeMiddlewares['GET:' + routeName] = handlers;
            }
            if (method === 'ALL' || method === 'POST') {
                this.routes['POST:' + routeName] = handler;
                this.routeMiddlewares['POST:' + routeName] = handlers;
            }
            if (method === 'ALL' || method === 'PUT') {
                this.routes['PUT:' + routeName] = handler;
                this.routeMiddlewares['PUT:' + routeName] = handlers;
            }
            if (method === 'ALL' || method === 'PATCH') {
                this.routes['PATCH:' + routeName] = handler;
                this.routeMiddlewares['PATCH:' + routeName] = handlers;
            }
            if (method === 'ALL' || method === 'DELETE') {
                this.routes['DELETE:' + routeName] = handler;
                this.routeMiddlewares['DELETE:' + routeName] = handlers;
            }
        };
        RouterService.prototype.disabled = function (method, routeName) {
            var disabledRoutes = this.optionService.getDisabledRoutes();
            var status = false;
            // cheking value (against disabledRoutes)
            var value = method.toLowerCase() + ':' + routeName;
            var valueUppercase = method.toUpperCase() + ':' + routeName;
            var valueSpaced = method.toLowerCase() + ' ' + routeName;
            var valueSpacedUppercase = method.toUpperCase() + ' ' + routeName;
            var values = [
                value,
                valueUppercase,
                (value).replace(':/', ':'),
                (valueUppercase).replace(':/', ':'),
                valueSpaced,
                valueSpacedUppercase,
                (valueSpaced).replace(' /', ' '),
                (valueSpacedUppercase).replace(' /', ' '),
            ];
            // check
            for (var i = 0; i < values.length; i++) {
                if (disabledRoutes.indexOf(values[i]) > -1) {
                    status = true;
                }
            }
            return status;
        };
        return RouterService;
    }());

    function sheetbase(options) {
        var Option = new OptionService(options);
        var Router = new RouterService(Option);
        var Request = new RequestService();
        var Response = new ResponseService(Option);
        var HTTP = new HttpService(Option, Response, Router);
        return {
            Option: Option,
            Router: Router,
            Request: Request,
            Response: Response,
            HTTP: HTTP
        };
    }

    var __assign$5 = function () {
        __assign$5 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$5.apply(this, arguments);
    };
    function loadAPIKeys(options) {
        var apiKeys = {};
        var validApiKeys = options.apiKeys, validKey = options.key;
        if (validKey) {
            apiKeys[validKey] = { title: 'Untitled', value: validKey };
        }
        else if (!!validApiKeys) {
            for (var _i = 0, _a = Object.keys(validApiKeys); _i < _a.length; _i++) {
                var k = _a[_i];
                var apiKey = validApiKeys[k];
                if (apiKey instanceof Object) { // apiKey = an object
                    apiKeys[k] = __assign$5({}, apiKey, { value: k });
                }
                else { // apiKey = string
                    apiKeys[k] = { title: apiKey, value: k };
                }
            }
        }
        return apiKeys;
    }
    function middleware(options) {
        if (options === void 0) { options = {}; }
        return function (req, res, next) {
            // 'apiKeys/apiKey' = objects/object (APIKey interface)
            // 'key' = string
            // get key from the request
            var key = req.body.key || req.query.key;
            var apiKeys = loadAPIKeys(options);
            var apiKey = key ? apiKeys[key] : null;
            if (!apiKey) {
                var failure = options.failure;
                if (!!(failure && failure.constructor && failure.call && failure.apply)) {
                    return failure(req, res);
                }
                else {
                    try {
                        return res.render('errors/403');
                    }
                    catch (error) {
                        return res.html('<h1>403!</h1><p>Unauthorized.</p>');
                    }
                }
            }
            else {
                var trigger = options.trigger;
                if (!!(trigger && trigger.constructor && trigger.call && trigger.apply)) {
                    trigger(req, apiKey);
                }
            }
            return next();
        };
    }

    function buildQuery(filter) {
        if (!filter['where']) { // shorthand query
            var where = Object.keys(filter)[0];
            var equal = filter[where];
            delete filter[where]; // remove shorthand value from filter
            filter['where'] = where;
            filter['equal'] = equal;
        }
        return filter;
    }
    function buildAdvancedFilter(query) {
        var advancedFilter;
        // build advanced filter
        var _a = query, where = _a.where, equal = _a.equal, exists = _a.exists, contains = _a.contains, lt = _a.lt, lte = _a.lte, gt = _a.gt, gte = _a.gte, childExists = _a.childExists, childEqual = _a.childEqual;
        if (!!equal) { // where/equal
            advancedFilter = function (item) { return (!!item[where] && item[where] === equal); };
        }
        else if (typeof exists === 'boolean') { // where/exists/not exists
            advancedFilter = function (item) { return (!!exists ? !!item[where] : !item[where]); };
        }
        else if (!!contains) { // where/contains
            advancedFilter = function (item) { return (typeof item[where] === 'string' &&
                item[where].indexOf(contains) > -1); };
        }
        else if (!!lt) { // where/less than
            advancedFilter = function (item) { return (typeof item[where] === 'number' &&
                item[where] < lt); };
        }
        else if (!!lte) { // where/less than or equal
            advancedFilter = function (item) { return (typeof item[where] === 'number' &&
                item[where] <= lte); };
        }
        else if (!!gt) { // where/greater than
            advancedFilter = function (item) { return (typeof item[where] === 'number' &&
                item[where] > gt); };
        }
        else if (!!gte) { // where/greater than or equal
            advancedFilter = function (item) { return (typeof item[where] === 'number' &&
                item[where] >= gte); };
        }
        else if (!!childExists) { // where/child exists, not exists
            var notExists_1 = childExists.substr(0, 1) === '!';
            var child_1 = notExists_1 ? childExists.replace('!', '') : childExists;
            advancedFilter = function (item) {
                if (!item[where] && notExists_1) {
                    return true; // child always not exists
                }
                else if (!!item[where]) {
                    if (item[where] instanceof Array) {
                        return notExists_1 ?
                            (item[where].indexOf(child_1) < 0) :
                            (item[where].indexOf(child_1) > -1);
                    }
                    else if (item[where] instanceof Object) {
                        return notExists_1 ? !item[where][child_1] : !!item[where][child_1];
                    }
                }
                return false;
            };
        }
        else if (!!childEqual) { // where/child equal, not equal
            var notEqual_1;
            var childKey_1;
            var childValue_1;
            if (childEqual.indexOf('!=') > -1) {
                notEqual_1 = true;
                var keyValue = childEqual.split('!=').filter(Boolean);
                childKey_1 = keyValue[0];
                childValue_1 = keyValue[1];
            }
            else {
                var keyValue = childEqual.split('=').filter(Boolean);
                childKey_1 = keyValue[0];
                childValue_1 = keyValue[1];
            }
            if (!isNaN(childValue_1)) {
                childValue_1 = Number(childValue_1);
            }
            advancedFilter = function (item) {
                if (!item[where] && notEqual_1) {
                    return true; // always not equal
                }
                else if (!!item[where]) {
                    return (item[where] instanceof Object &&
                        (notEqual_1 ?
                            (!item[where][childKey_1] || item[where][childKey_1] !== childValue_1) :
                            (!!item[where][childKey_1] && item[where][childKey_1] === childValue_1)));
                }
                return false;
            };
        }
        return advancedFilter;
    }
    function buildSegmentFilter(segment) {
        var segmentFilter = function (item) {
            var result = false;
            var segmentArr = Object.keys(segment || {});
            if (!segmentArr.length) {
                result = true;
            }
            // from 1-3
            else if (segmentArr.length < 4) {
                var first = segmentArr[0], second = segmentArr[1], third = segmentArr[2];
                result = (
                // 1st
                (!item[first] ||
                    item[first] === segment[first]) &&
                    // 2nd
                    (!second ||
                        !item[second] ||
                        item[second] === segment[second]) &&
                    // 3rd
                    (!third ||
                        !item[third] ||
                        item[third] === segment[third]));
            }
            // over 3
            else {
                result = true; // assumpt
                for (var i = 0; i < segmentArr.length; i++) {
                    var seg = segmentArr[i];
                    // any not matched
                    if (!!item[seg] &&
                        item[seg] !== segment[seg]) {
                        result = false;
                        break;
                    }
                }
            }
            return result;
        };
        return segmentFilter;
    }

    // turn [[],[], ...] to [{},{}, ...]
    function translateRangeValues(values, noHeader, modifier) {
        if (noHeader === void 0) { noHeader = false; }
        if (modifier === void 0) { modifier = function (item) { return item; }; }
        values = values || [];
        // get header
        var headers = !noHeader ? values.shift() : [];
        // build data
        var result = [];
        for (var i = 0; i < values.length; i++) {
            var item = {};
            // process columns
            var rows = values[i] || [];
            for (var j = 0; j < rows.length; j++) {
                if (rows[j]) {
                    item[headers[j] || ('value' + (j + 1))] = rows[j];
                }
            }
            if (Object.keys(item).length > 0) {
                item['_row'] = !noHeader ? i + 2 : i + 1;
                result.push(modifier(item));
            }
        }
        return result;
    }
    // convert string of data load from spreadsheet to correct data type
    function parseData(item) {
        for (var _i = 0, _a = Object.keys(item); _i < _a.length; _i++) {
            var key = _a[_i];
            if (item[key] === '' || item[key] === null || item[key] === undefined) {
                // delete null key
                delete item[key];
            }
            else if ((item[key] + '').toLowerCase() === 'true') {
                // boolean TRUE
                item[key] = true;
            }
            else if ((item[key] + '').toLowerCase() === 'false') {
                // boolean FALSE
                item[key] = false;
            }
            else if (!isNaN(item[key])) {
                // number
                item[key] = Number(item[key]);
            }
            else if (typeof item[key] === 'string' &&
                ((item[key].substr(0, 1) === '{' && item[key].substr(-1) === '}') ||
                    (item[key].substr(0, 1) === '[' && item[key].substr(-1) === ']'))) {
                // JSON
                try {
                    item[key] = JSON.parse(item[key]);
                }
                catch (e) {
                    // continue
                }
            }
        }
        return item;
    }
    function o2a(object, keyName) {
        if (keyName === void 0) { keyName = '$key'; }
        var arr = [];
        for (var _i = 0, _a = Object.keys(object || {}); _i < _a.length; _i++) {
            var key = _a[_i];
            if (object[key] instanceof Object) {
                object[key][keyName] = key;
            }
            else {
                var value = object[key];
                object[key] = {};
                object[key][keyName] = key;
                object[key]['value'] = value;
            }
            arr.push(object[key]);
        }
        return arr;
    }
    function uniqueId$1(length, startWith) {
        if (length === void 0) { length = 12; }
        if (startWith === void 0) { startWith = '-'; }
        var maxLoop = length - 8;
        var ASCII_CHARS = startWith + '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz';
        var lastPushTime = 0;
        var lastRandChars = [];
        var now = new Date().getTime();
        var duplicateTime = (now === lastPushTime);
        lastPushTime = now;
        var timeStampChars = new Array(8);
        var i;
        for (i = 7; i >= 0; i--) {
            timeStampChars[i] = ASCII_CHARS.charAt(now % 64);
            now = Math.floor(now / 64);
        }
        var uid = timeStampChars.join('');
        if (!duplicateTime) {
            for (i = 0; i < maxLoop; i++) {
                lastRandChars[i] = Math.floor(Math.random() * 64);
            }
        }
        else {
            for (i = maxLoop - 1; i >= 0 && lastRandChars[i] === 63; i--) {
                lastRandChars[i] = 0;
            }
            lastRandChars[i]++;
        }
        for (i = 0; i < maxLoop; i++) {
            uid += ASCII_CHARS.charAt(lastRandChars[i]);
        }
        return uid;
    }

    var __assign$4 = function () {
        __assign$4 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$4.apply(this, arguments);
    };
    var RefService = /** @class */ (function () {
        function RefService(paths, Sheets) {
            this.paths = paths;
            this.Sheets = Sheets;
        }
        RefService.prototype.keyField = function (sheetName) {
            return this.Sheets.options.keyFields[sheetName] || '$key';
        };
        // load sheet data
        RefService.prototype.loadDataBySheet = function (sheetName, fresh) {
            if (fresh === void 0) { fresh = false; }
            if (!this.Sheets.database[sheetName] || fresh) {
                // load raw items
                var rawItems = translateRangeValues(this.Sheets.spreadsheet.getRange(sheetName + '!A1:ZZ').getValues());
                // process items
                var items = {};
                for (var i = 0; i < rawItems.length; i++) {
                    var item = parseData(rawItems[i]);
                    // get item key
                    var key = item[this.keyField(sheetName)];
                    // add '$key' field
                    item['$key'] = key;
                    // set items
                    items[key] = item;
                }
                // save to database
                this.Sheets.database[sheetName] = items;
            }
            return this.Sheets.database[sheetName];
        };
        // load all data
        RefService.prototype.loadRootData = function () {
            // load all sheets
            var sheets = this.Sheets.spreadsheet.getSheets();
            // load data sheet by sheet
            for (var i = 0; i < sheets.length; i++) {
                var sheetName = sheets[i].getName();
                if (sheetName.substr(0, 2) === '__' &&
                    sheetName.substr(sheetName.length - 2, 2) === '__') ;
                else {
                    this.loadDataBySheet(sheetName);
                }
            }
            return this.Sheets.database;
        };
        // get data at this ref location
        RefService.prototype.data = function () {
            var _a = this.paths, sheetName = _a[0], paths = _a.slice(1);
            var data = {};
            if (!sheetName) { // root data
                data = __assign$4({}, this.loadRootData());
            }
            else { // sheet data
                data = __assign$4({}, this.loadDataBySheet(sheetName));
            }
            // get deep
            for (var i = 0; i < paths.length; i++) {
                if (data instanceof Object) {
                    data = data[paths[i]] || null;
                }
                else {
                    data = null;
                    break;
                }
            }
            return data;
        };
        /**
         * ref navigation
         */
        RefService.prototype.root = function () {
            return new RefService([], this.Sheets);
        };
        RefService.prototype.parent = function () {
            var paths = this.paths.slice();
            if (paths.length > 0) {
                paths.pop();
                return new RefService(paths, this.Sheets);
            }
            else {
                return this.root();
            }
        };
        RefService.prototype.child = function (path) {
            var childPaths = path.split('/').filter(Boolean);
            var paths = this.paths.concat(childPaths);
            return new RefService(paths, this.Sheets);
        };
        /**
         * read data
         */
        RefService.prototype.key = function (length, startWith) {
            if (length === void 0) { length = 27; }
            if (startWith === void 0) { startWith = '-'; }
            return uniqueId$1(length, startWith);
        };
        RefService.prototype.toObject = function () {
            this.Sheets.Security.checkpoint('read', this.paths, this);
            return this.data();
        };
        RefService.prototype.toArray = function () {
            return o2a(this.toObject());
        };
        RefService.prototype.query = function (advancedFilter, segment) {
            if (segment === void 0) { segment = null; }
            if (this.paths.length === 1) {
                var result = [];
                // build segment filter
                var segmentFilter = buildSegmentFilter(segment);
                // go through items, filter and check for security
                var items = this.data();
                for (var _i = 0, _a = Object.keys(items); _i < _a.length; _i++) {
                    var key = _a[_i];
                    var item = items[key];
                    if (!!segmentFilter(item) &&
                        !!advancedFilter(item)) {
                        var itemRef = this.child(key);
                        this.Sheets.Security.checkpoint('read', itemRef.paths, itemRef);
                        result.push(item);
                    }
                }
                return result;
            }
            else {
                throw new Error('Can only query list ref.');
            }
        };
        /**
         * add/update/remove/...
         */
        RefService.prototype.set = function (data) {
            if (data === void 0) { data = null; }
            return this.update(data, true);
        };
        RefService.prototype.update = function (data, clean) {
            var _a, _b;
            if (data === void 0) { data = null; }
            if (clean === void 0) { clean = false; }
            if (this.paths.length > 0) {
                var _c = this.paths, sheetName = _c[0], _itemKey = _c[1];
                // get sheet
                var sheet = this.Sheets.spreadsheet.getSheetByName(sheetName);
                // get item
                var items = this.loadDataBySheet(sheetName);
                var itemKey = _itemKey || this.key();
                var item = items[itemKey];
                // determine which action
                var action = void 0;
                if (!data && !!item) { // remove
                    action = 'remove';
                }
                else if (!!data && !!item) { // update
                    action = 'update';
                }
                else if (!!data && !item) { // new
                    action = 'new';
                }
                // prepare data
                var _row = void 0;
                if (action === 'remove') { // remove
                    _row = item._row;
                }
                else if (action === 'update') { // update
                    _row = item._row;
                    var newItem = __assign$4({}, data, (_a = { '#': item['#'] }, _a[this.keyField(sheetName)] = itemKey, _a._row = _row, _a));
                    if (clean) { // set
                        item = newItem;
                    }
                    else { // update
                        item = __assign$4({}, item, newItem);
                    }
                }
                else if (action === 'new') { // new
                    var lastRow = sheet.getLastRow();
                    var lastItemId = sheet.getRange('A' + lastRow + ':' + lastRow).getValues()[0][0];
                    _row = lastRow + 1;
                    item = __assign$4({}, data, (_b = { '#': !isNaN(lastItemId) ? (lastItemId + 1) : 1 }, _b[this.keyField(sheetName)] = itemKey, _b._row = _row, _b));
                }
                // check permission
                this.Sheets.Security.checkpoint('write', this.paths, this, item, data);
                // build range values
                var rangeValues = [];
                var headers = sheet.getRange('A1:1').getValues()[0];
                for (var i = 0; i < headers.length; i++) {
                    if (action === 'remove') {
                        rangeValues.push('');
                    }
                    else {
                        var value = item[headers[i]];
                        // stringify
                        if (value instanceof Object) {
                            value = JSON.stringify(value);
                        }
                        rangeValues.push(value || '');
                    }
                }
                // set snapshot database
                if (action === 'remove') { // remove
                    delete items[itemKey];
                }
                else { // update / new
                    items[itemKey] = item;
                }
                // set live database
                sheet.getRange('A' + _row + ':' + _row).setValues([rangeValues]);
                return action === 'remove' ? null : item;
            }
            else {
                throw new Error('Can only modify list ref (new) and item ref.');
            }
        };
        RefService.prototype.increase = function (increasing) {
            var _a;
            if (this.paths.length === 2) {
                var item = this.data();
                var data = {}; // changed data
                // turn a path or array of paths to increasing object
                if (typeof increasing === 'string') {
                    increasing = (_a = {}, _a[increasing] = 1, _a);
                }
                else if (increasing instanceof Array) {
                    var _increasing = {};
                    for (var i = 0; i < increasing.length; i++) {
                        _increasing[increasing[i]] = 1;
                    }
                    increasing = _increasing;
                }
                // increase props
                for (var _i = 0, _b = Object.keys(increasing); _i < _b.length; _i++) {
                    var path = _b[_i];
                    var _c = path.split('/').filter(Boolean), itemKey = _c[0], childKey = _c[1];
                    var increasedBy = increasing[path] || 1;
                    if (!isNaN(increasedBy)) { // only number
                        // set value
                        if (!!childKey) { // deep props
                            var child = item[itemKey] || {};
                            // only apply for object
                            if (child instanceof Object) {
                                // only for number prop
                                if (!child[childKey] ||
                                    (!!child[childKey] && typeof child[childKey] === 'number')) {
                                    // set child
                                    child[childKey] = (child[childKey] || 0) + increasedBy;
                                    // set item
                                    item[itemKey] = child;
                                    // set changed
                                    data[itemKey] = child;
                                }
                            }
                        }
                        else { // direct prop
                            // only for number prop
                            if (!item[itemKey] ||
                                (!!item[itemKey] && typeof item[itemKey] === 'number')) {
                                // set item
                                item[itemKey] = (item[itemKey] || 0) + increasedBy;
                                // set changed
                                data[itemKey] = item[itemKey];
                            }
                        }
                    }
                }
                // finally
                // save changed data to database
                this.update(data);
                return item;
            }
            else {
                throw new Error('Can only increasing item ref.');
            }
        };
        return RefService;
    }());

    var __assign$1$2 = function () {
        __assign$1$2 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$1$2.apply(this, arguments);
    };
    var DataSnapshot = /** @class */ (function () {
        function DataSnapshot(input, securityHelpers) {
            var _this = this;
            this.isRef = false;
            this.input = input;
            if (input instanceof RefService) {
                this.isRef = true;
            }
            // add helpers
            if (!!securityHelpers) {
                var _loop_1 = function (key) {
                    var helper = securityHelpers[key];
                    this_1[key] = function () { return helper(_this); };
                };
                var this_1 = this;
                for (var _i = 0, _a = Object.keys(securityHelpers); _i < _a.length; _i++) {
                    var key = _a[_i];
                    _loop_1(key);
                }
            }
        }
        // get data
        DataSnapshot.prototype.val = function () {
            if (this.isRef) {
                return this.input['data']();
            }
            else {
                return this.input;
            }
        };
        // only props
        DataSnapshot.prototype.only = function (props) {
            if (props === void 0) { props = []; }
            var data = this.val();
            if (!props || !props.length) {
                return true;
            }
            else if (!!data && data instanceof Object) {
                var _data = __assign$1$2({}, data);
                for (var i = 0; i < props.length; i++) {
                    var prop = props[i];
                    delete _data[prop];
                }
                return Object.keys(_data).length === 0;
            }
            else {
                return false;
            }
        };
        return DataSnapshot;
    }());

    var __assign$2$1 = function () {
        __assign$2$1 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$2$1.apply(this, arguments);
    };
    var SecurityService = /** @class */ (function () {
        function SecurityService(Sheets) {
            this.req = null;
            this.auth = null;
            this.Sheets = Sheets;
        }
        SecurityService.prototype.setRequest = function (request) {
            // req object
            this.req = request;
            // auth object
            var AuthToken = this.Sheets.options.AuthToken;
            var idToken = !!request ? (request.query['idToken'] || request.body['idToken']) : null;
            if (!!idToken && !!AuthToken) {
                this.auth = AuthToken.decodeIdToken(idToken);
            }
        };
        SecurityService.prototype.checkpoint = function (permission, paths, ref, item, data) {
            if (item === void 0) { item = null; }
            if (data === void 0) { data = null; }
            // read
            if (permission === 'read' &&
                !this.hasPermission('read', paths, ref)) {
                throw new Error('No read permission.');
            }
            // write
            if (permission === 'write' &&
                !this.hasPermission('write', paths, ref, item, data)) {
                throw new Error('No write permission.');
            }
        };
        SecurityService.prototype.hasPermission = function (permission, paths, ref, item, data) {
            var security = this.Sheets.options.security;
            // always when security is off
            if (!security) {
                return true;
            }
            // user claims has admin previledge
            if (!!this.auth && this.auth.isAdmin) {
                return true;
            }
            // execute rule
            var _a = this.parseRule(permission, paths), rule = _a.rule, dynamicData = _a.dynamicData;
            return (typeof rule === 'boolean') ? rule :
                this.executeRule(rule, ref, item, data, dynamicData);
        };
        SecurityService.prototype.executeRule = function (rule, ref, item, data, dynamicData) {
            if (dynamicData === void 0) { dynamicData = {}; }
            var customHelpers = this.Sheets.options.securityHelpers;
            // sum up input
            var input = __assign$2$1({ now: new Date(), req: this.req, auth: this.auth, root: new DataSnapshot(ref.root(), customHelpers), data: new DataSnapshot(ref, customHelpers), newData: new DataSnapshot(item, customHelpers), inputData: new DataSnapshot(data, customHelpers) }, dynamicData);
            var body = "\n            Object.keys(input).map(function (k) {\n                this[k] = input[k];\n            });\n            return (" + rule + ");\n        ";
            // run
            try {
                var executor = new Function('input', body);
                return executor(input);
            }
            catch (error) {
                return false;
            }
        };
        SecurityService.prototype.parseRule = function (permission, paths) {
            var security = this.Sheets.options.security;
            // prepare
            var rules = {};
            if (security === false) {
                // implicit no security (public)
                rules = { '.read': true, '.write': true };
            }
            else if (!security || security === true) {
                // undefined or null or true (private)
                rules = { '.read': false, '.write': false };
            }
            else {
                // rule based
                rules = security;
            }
            var latestRules = {
                '.read': rules['.read'] || false,
                '.write': rules['.write'] || false
            };
            var dynamicData = {};
            var _loop_1 = function (i) {
                // current step values
                var path = paths[i];
                var dynamicKey;
                // set rules
                var nextRules = rules[path];
                if (!!nextRules && nextRules instanceof Object) {
                    rules = nextRules;
                }
                else {
                    // get latest dynamic key
                    Object.keys(rules).map(function (k) {
                        dynamicKey = (k.substr(0, 1) === '$') ? k : null;
                    });
                    // if it have any dynamic key, use it
                    var dynamicRules = rules[dynamicKey];
                    if (!!dynamicRules && dynamicRules instanceof Object) {
                        rules = dynamicRules;
                    }
                    else {
                        rules = {};
                    }
                }
                // set latestRules
                var _a = rules, read = _a[".read"], write = _a[".write"];
                if (read === false || !!read) {
                    latestRules['.read'] = read;
                }
                if (write === false || !!write) {
                    latestRules['.write'] = write;
                }
                // set dynamicData
                if (!!dynamicKey) {
                    dynamicData[dynamicKey] = path;
                }
            };
            // get data
            for (var i = 0; i < paths.length; i++) {
                _loop_1(i);
            }
            // set rule
            var endedRule = rules['.' + permission];
            var rule = (endedRule === false || !!endedRule) ? endedRule : latestRules['.' + permission];
            // return data
            return { rule: rule, dynamicData: dynamicData };
        };
        return SecurityService;
    }());

    var __assign$3$1 = function () {
        __assign$3$1 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$3$1.apply(this, arguments);
    };
    var SheetsService = /** @class */ (function () {
        function SheetsService(options, database) {
            // TODO: add route errors
            this.errors = {};
            this.options = __assign$3$1({ keyFields: {}, security: {}, securityHelpers: {} }, options);
            this.database = database;
            this.Security = new SecurityService(this);
            this.spreadsheet = SpreadsheetApp.openById(options.databaseId);
        }
        SheetsService.prototype.setIntegration = function (key, value) {
            this.options[key] = value;
            return this;
        };
        SheetsService.prototype.extend = function (options) {
            return new SheetsService(__assign$3$1({}, this.options, options), this.database);
        };
        SheetsService.prototype.toAdmin = function () {
            return this.extend({ security: false });
        };
        SheetsService.prototype.ref = function (path) {
            if (path === void 0) { path = '/'; }
            return new RefService(path.split('/').filter(Boolean), this);
        };
        SheetsService.prototype.key = function (length, startWith) {
            if (length === void 0) { length = 27; }
            if (startWith === void 0) { startWith = '-'; }
            return this.ref().key(length, startWith);
        };
        SheetsService.prototype.data = function (sheetName) {
            return this.ref('/' + sheetName).toObject();
        };
        SheetsService.prototype.all = function (sheetName) {
            return this.ref('/' + sheetName).toArray();
        };
        SheetsService.prototype.query = function (sheetName, filter, segment) {
            if (segment === void 0) { segment = null; }
            var advancedFilter;
            if (filter instanceof Function) {
                advancedFilter = filter;
            }
            else {
                advancedFilter = buildAdvancedFilter(buildQuery(filter));
            }
            return this.ref('/' + sheetName).query(advancedFilter, segment);
        };
        SheetsService.prototype.items = function (sheetName, filter, segment) {
            if (segment === void 0) { segment = null; }
            return !!filter ? this.query(sheetName, filter, segment) : this.all(sheetName);
        };
        SheetsService.prototype.item = function (sheetName, finder, segment) {
            if (segment === void 0) { segment = null; }
            var item = null;
            if (typeof finder === 'string') {
                var key = finder;
                item = this.ref('/' + sheetName + '/' + key).toObject();
            }
            else {
                var items = this.query(sheetName, finder, segment);
                if (!!items && items.length === 1) {
                    item = items[0];
                }
            }
            return item;
        };
        SheetsService.prototype.set = function (sheetName, key, data) {
            return this.ref('/' + sheetName + (!!key ? ('/' + key) : '')).set(data);
        };
        SheetsService.prototype.update = function (sheetName, key, data) {
            return this.ref('/' + sheetName + (!!key ? ('/' + key) : '')).update(data);
        };
        SheetsService.prototype.add = function (sheetName, key, data) {
            return this.update(sheetName, key, data);
        };
        SheetsService.prototype.remove = function (sheetName, key) {
            return this.update(sheetName, key, null);
        };
        SheetsService.prototype.increase = function (sheetName, key, increasing) {
            return this.ref('/' + sheetName + (!!key ? ('/' + key) : '')).increase(increasing);
        };
        SheetsService.prototype.docsContent = function (docId, style) {
            if (style === void 0) { style = 'clean'; }
            DriveApp.getStorageUsed(); // trigger authorization
            // cache
            var cacheService = CacheService.getScriptCache();
            var cacheKey = 'content_' + docId + '_' + style;
            // get content
            var content = '';
            var cachedContent = cacheService.get(cacheKey);
            if (!!cachedContent) {
                content = cachedContent;
            }
            else {
                // fetch
                var url = 'https://www.googleapis.com/drive/v3/files/' + docId + '/export?mimeType=text/html';
                var response = UrlFetchApp.fetch(url, {
                    method: 'get',
                    headers: {
                        Authorization: 'Bearer ' + ScriptApp.getOAuthToken()
                    },
                    muteHttpExceptions: true
                });
                // finalize content
                if (!!response && response.getResponseCode() === 200) {
                    var html = response.getContentText();
                    // original
                    content = html || '';
                    // full & clean
                    if (style !== 'original') {
                        // extract content, between: </head></html>
                        var contentMatch = html.match(/\<\/head\>(.*)\<\/html\>/);
                        if (!!contentMatch) {
                            content = contentMatch.pop();
                        }
                        // clean up
                        content = content
                            .replace(/\<body(.*?)\>/, '') // replace: <body...>
                            .replace('</body>', '') // replace </body>
                            .replace(/\<script(.*?)\<\/script\>/g, '') // remove all script tag
                            .replace(/\<style(.*?)\<\/style\>/g, ''); // remove all style tag
                        // replace redirect links
                        var links = content.match(/\"https\:\/\/www\.google\.com\/url\?q\=(.*?)\"/g);
                        if (!!links) {
                            for (var i = 0, l = links.length; i < l; i++) {
                                var link = links[i];
                                var urlMatch = link
                                    .match(/\"https\:\/\/www\.google\.com\/url\?q\=(.*?)\&amp\;/);
                                if (!!urlMatch) {
                                    var url_1 = urlMatch.pop();
                                    content = content.replace(link, '"' + url_1 + '"');
                                }
                            }
                        }
                        // clean
                        if (style === 'clean') {
                            // remove all attributes
                            var removeAttrs = ['style', 'id', 'class', 'width', 'height'];
                            for (var i = 0, l = removeAttrs.length; i < l; i++) {
                                content = content.replace(new RegExp('\ ' + removeAttrs[i] + '\=\"(.*?)\"', 'g'), '');
                            }
                        }
                    }
                    // save to cache
                    try {
                        cacheService.put(cacheKey, content, 3600); // 1 hour
                    }
                    catch (error) {
                        // cache error (may be content larger 100K)
                    }
                }
                else {
                    throw new Error('Fetch failed.');
                }
            }
            // return content
            return content;
        };
        // routes
        SheetsService.prototype.registerRoutes = function (options) {
            var _this = this;
            var router = options.router, _a = options.endpoint, endpoint = _a === void 0 ? 'database' : _a, _b = options.disabledRoutes, disabledRoutes = _b === void 0 ? [
                'post:/' + endpoint,
                'put:/' + endpoint,
                'patch:/' + endpoint,
                'delete:/' + endpoint,
            ] : _b, _c = options.middlewares, middlewares = _c === void 0 ? [function (req, res, next) { return next(); }] : _c;
            // register errors & disabled routes
            router.setDisabled(disabledRoutes);
            router.setErrors(this.errors);
            // register request for security
            middlewares.push(function (req, res, next) {
                _this.Security.setRequest(req);
                return next();
            });
            router.get.apply(router, ['/' + endpoint].concat(middlewares, [function (req, res) {
                    var _a = req.query, _b = _a.path, path = _b === void 0 ? '/' : _b, // sheet name and item key
                    table = _a.table, sheet = _a.sheet, // sheet name
                    id = _a.id, key = _a.key, // item key
                    // query
                    where = _a.where, equal = _a.equal, exists = _a.exists, contains = _a.contains, lt = _a.lt, lte = _a.lte, gt = _a.gt, gte = _a.gte, childExists = _a.childExists, childEqual = _a.childEqual, 
                    // type
                    _c = _a.type, 
                    // type
                    type = _c === void 0 ? 'list' : _c, segment = _a.segment;
                    var paths = path.split('/').filter(Boolean);
                    var sheetName = table || sheet || paths[0];
                    var itemKey = id || key || paths[1];
                    if (!sheetName) {
                        return res.error('No path/table/sheet.');
                    }
                    var result;
                    try {
                        if (!!itemKey) { // get item
                            result = _this.item(sheetName, itemKey);
                        }
                        else if (!!where) { // query
                            result = _this.query(sheetName, {
                                where: where,
                                equal: equal,
                                exists: exists,
                                contains: contains,
                                lt: lt, lte: lte,
                                gt: gt, gte: gte,
                                childExists: childExists,
                                childEqual: childEqual
                            }, segment);
                        }
                        else if (type === 'object') {
                            result = _this.data(sheetName);
                        }
                        else { // all
                            result = _this.all(sheetName);
                        }
                    }
                    catch (error) {
                        return res.error(error);
                    }
                    return res.success(result);
                }]));
            var updateHandler = function (req, res) {
                var _a = req.body, _b = _a.path, path = _b === void 0 ? '/' : _b, // sheet name and item key
                table = _a.table, sheet = _a.sheet, // sheet name
                id = _a.id, key = _a.key, // item key
                _c = _a.data, // item key
                data = _c === void 0 ? null : _c, // data
                _d = _a.increasing, // data
                increasing = _d === void 0 ? null : _d, //increasing
                _e = _a.clean, //increasing
                clean = _e === void 0 ? false : _e;
                var paths = path.split('/').filter(Boolean);
                var sheetName = table || sheet || paths[0];
                var itemKey = id || key || paths[1] || null;
                if (!sheetName) {
                    return res.error('No path/table/sheet.');
                }
                try {
                    if (!!increasing) {
                        _this.increase(sheetName, itemKey, increasing);
                    }
                    else if (clean) {
                        _this.set(sheetName, itemKey, data);
                    }
                    else {
                        _this.update(sheetName, itemKey, data);
                    }
                }
                catch (error) {
                    return res.error(error);
                }
                return res.success({ acknowledge: true });
            };
            router.post.apply(router, ['/' + endpoint].concat(middlewares, [updateHandler]));
            router.put.apply(router, ['/' + endpoint].concat(middlewares, [updateHandler]));
            router.patch.apply(router, ['/' + endpoint].concat(middlewares, [updateHandler]));
            router["delete"].apply(router, ['/' + endpoint].concat(middlewares, [updateHandler]));
            router.get.apply(router, ['/' + endpoint + '/content'].concat(middlewares, [function (req, res) {
                    var _a = req.query, docId = _a.docId, style = _a.style;
                    if (!docId) {
                        return res.error('No doc id.');
                    }
                    var result;
                    try {
                        var content = _this.docsContent(docId, style);
                        result = { docId: docId, content: content };
                    }
                    catch (error) {
                        return res.error(error);
                    }
                    return res.success(result);
                }]));
        };
        return SheetsService;
    }());

    var DATABASE = {};
    function sheets(options) {
        return new SheetsService(options, DATABASE);
    }

    var __assign$3 = function () {
        __assign$3 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$3.apply(this, arguments);
    };
    var GmailService = /** @class */ (function () {
        function GmailService(options) {
            this.errors = {
                'mail/missing-data': 'Missing mailing data.'
            };
            this.options = __assign$3({ categories: {}, templates: {} }, options);
            this.options.categories['uncategorized'] = {
                title: 'Uncategorized',
                silent: true
            };
        }
        GmailService.prototype.registerRoutes = function (options) {
            var _this = this;
            var router = options.router, _a = options.endpoint, endpoint = _a === void 0 ? 'mail' : _a, _b = options.disabledRoutes, disabledRoutes = _b === void 0 ? [
                'post:/' + endpoint,
            ] : _b, _c = options.middlewares, middlewares = _c === void 0 ? [function (req, res, next) { return next(); }] : _c;
            // register errors & disabled routes
            router.setDisabled(disabledRoutes);
            router.setErrors(this.errors);
            // get daily quota
            router.get.apply(router, ['/' + endpoint].concat(middlewares, [function (req, res) {
                    var result;
                    try {
                        result = _this.quota();
                    }
                    catch (code) {
                        return res.error(code);
                    }
                    return res.success(result);
                }]));
            // send an email
            router.post.apply(router, ['/' + endpoint].concat(middlewares, [function (req, res) {
                    var _a = req.body, mailingData = _a.mailingData, _b = _a.category, category = _b === void 0 ? 'uncategorized' : _b, _c = _a.template, template = _c === void 0 ? null : _c, _d = _a.silent, silent = _d === void 0 ? null : _d;
                    var result;
                    try {
                        result = _this.send(mailingData, category, template, silent);
                    }
                    catch (code) {
                        return res.error(code);
                    }
                    return res.success(result);
                }]));
        };
        GmailService.prototype.send = function (mailingData, categoryName, template, customSilent) {
            if (categoryName === void 0) { categoryName = 'uncategorized'; }
            if (template === void 0) { template = null; }
            if (customSilent === void 0) { customSilent = null; }
            if (!mailingData ||
                !mailingData.recipient) {
                throw new Error('mail/missing-data');
            }
            // category
            var category = this.getCategory(categoryName, customSilent);
            // data
            var _a = this.processMailingData(mailingData, template, category.silent), recipient = _a.recipient, subject = _a.subject, body = _a.body, options = _a.options;
            // send email
            GmailApp.sendEmail(recipient, subject, body, options);
            var thread = this.processThread(recipient, category);
            // result
            return { threadId: thread.getId() };
        };
        GmailService.prototype.quota = function () {
            return { remainingDailyQuota: MailApp.getRemainingDailyQuota() };
        };
        GmailService.prototype.getCategory = function (categoryName, silent) {
            var categories = this.options.categories;
            // category
            var category = categories[categoryName] || categories['uncategorized'];
            if (typeof category === 'string') {
                category = { title: category, silent: false };
            }
            // override category silent
            if (silent !== null && silent !== undefined) {
                category.silent = !!silent;
            }
            return category;
        };
        GmailService.prototype.processMailingData = function (mailingData, template, silent) {
            var _a = this.options, prefix = _a.prefix, forwarding = _a.forwarding, templates = _a.templates;
            var recipient = mailingData.recipient, _b = mailingData.subject, subject = _b === void 0 ? 'A email sent by Sheetbase app' : _b, body = mailingData.body, _c = mailingData.options, options = _c === void 0 ? {} : _c;
            // forwarding
            if (!!forwarding && !silent) {
                options['bcc'] = !!options['bcc'] ? (options['bcc'] + ', ' + forwarding) : forwarding;
            }
            // templating (htmlBody)
            if (!!template) {
                // load template
                var templateName = Object.keys(template)[0];
                var data = template[templateName] || {};
                var templating = templates[templateName] || (function (data) { return ('<p><code><pre>' + JSON.stringify(data, null, 3) + '</pre></code></p>'); });
                // build html body
                options['htmlBody'] = templating(data);
            }
            // final data
            return {
                recipient: recipient,
                subject: "(" + prefix + ") " + subject,
                body: body /* input body */ || (!!options['htmlBody'] ?
                    // text version of html body
                    options['htmlBody'].replace(/<[^>]*>?/g, '') :
                    // default body
                    'This email was sent by a Sheetbase backend app.'),
                options: options
            };
        };
        GmailService.prototype.processThread = function (recipient, category) {
            var _a = this.options, forwarding = _a.forwarding, prefix = _a.prefix;
            // retrieve sent thread
            Utilities.sleep(2000);
            var sentThreads = GmailApp.search('from:me to:' + recipient);
            var thread = sentThreads[0];
            // add label
            thread.addLabel(this.getLabel(prefix + ':' + category.title));
            // move item to inbox and set unread
            // if no forwarding
            if (!forwarding && !category.silent) {
                thread.markUnread().moveToInbox();
            }
            return thread;
        };
        GmailService.prototype.getLabel = function (name) {
            var label = GmailApp.getUserLabelByName(name);
            if (!label) {
                label = GmailApp.createLabel(name);
            }
            return label;
        };
        return GmailService;
    }());

    function gmail(options) {
        return new GmailService(options);
    }

    var SheetsDriver = /** @class */ (function () {
        function SheetsDriver(Sheets) {
            this.Sheets = Sheets;
        }
        SheetsDriver.prototype.getUser = function (finder) {
            return this.Sheets.item('users', finder);
        };
        SheetsDriver.prototype.addUser = function (uid, userData) {
            this.Sheets.add('users', uid, userData);
        };
        SheetsDriver.prototype.updateUser = function (uid, userData) {
            this.Sheets.update('users', uid, userData);
        };
        SheetsDriver.prototype.deleteUser = function (uid) {
            this.Sheets.remove('users', uid);
        };
        return SheetsDriver;
    }());

    /*
     * jsrsasign(jwths) 8.0.12 (2018-04-22) (c) 2010-2018 Kenji Urushima | kjur.github.com/jsrsasign/license
     */
    var navigator = navigator || {};
    var window = window || {};

    /*!
    Copyright (c) 2011, Yahoo! Inc. All rights reserved.
    Code licensed under the BSD License:
    http://developer.yahoo.com/yui/license.html
    version: 2.9.0
    */
    if(YAHOO===undefined){var YAHOO={};}YAHOO.lang={extend:function(g,h,f){if(!h||!g){throw new Error("YAHOO.lang.extend failed, please check that all dependencies are included.")}var d=function(){};d.prototype=h.prototype;g.prototype=new d();g.prototype.constructor=g;g.superclass=h.prototype;if(h.prototype.constructor==Object.prototype.constructor){h.prototype.constructor=h;}if(f){var b;for(b in f){g.prototype[b]=f[b];}var e=function(){},c=["toString","valueOf"];try{if(/MSIE/.test(navigator.userAgent)){e=function(j,i){for(b=0;b<c.length;b=b+1){var l=c[b],k=i[l];if(typeof k==="function"&&k!=Object.prototype[l]){j[l]=k;}}};}}catch(a){}e(g.prototype,f);}}};

    /*! CryptoJS v3.1.2 core-fix.js
     * code.google.com/p/crypto-js
     * (c) 2009-2013 by Jeff Mott. All rights reserved.
     * code.google.com/p/crypto-js/wiki/License
     * THIS IS FIX of 'core.js' to fix Hmac issue.
     * https://code.google.com/p/crypto-js/issues/detail?id=84
     * https://crypto-js.googlecode.com/svn-history/r667/branches/3.x/src/core.js
     */
    var CryptoJS=CryptoJS||(function(e,g){var a={};var b=a.lib={};var j=b.Base=(function(){function n(){}return {extend:function(p){n.prototype=this;var o=new n();if(p){o.mixIn(p);}if(!o.hasOwnProperty("init")){o.init=function(){o.$super.init.apply(this,arguments);};}o.init.prototype=o;o.$super=this;return o},create:function(){var o=this.extend();o.init.apply(o,arguments);return o},init:function(){},mixIn:function(p){for(var o in p){if(p.hasOwnProperty(o)){this[o]=p[o];}}if(p.hasOwnProperty("toString")){this.toString=p.toString;}},clone:function(){return this.init.prototype.extend(this)}}}());var l=b.WordArray=j.extend({init:function(o,n){o=this.words=o||[];if(n!=g){this.sigBytes=n;}else {this.sigBytes=o.length*4;}},toString:function(n){return (n||h).stringify(this)},concat:function(t){var q=this.words;var p=t.words;var n=this.sigBytes;var s=t.sigBytes;this.clamp();if(n%4){for(var r=0;r<s;r++){var o=(p[r>>>2]>>>(24-(r%4)*8))&255;q[(n+r)>>>2]|=o<<(24-((n+r)%4)*8);}}else {for(var r=0;r<s;r+=4){q[(n+r)>>>2]=p[r>>>2];}}this.sigBytes+=s;return this},clamp:function(){var o=this.words;var n=this.sigBytes;o[n>>>2]&=4294967295<<(32-(n%4)*8);o.length=e.ceil(n/4);},clone:function(){var n=j.clone.call(this);n.words=this.words.slice(0);return n},random:function(p){var o=[];for(var n=0;n<p;n+=4){o.push((e.random()*4294967296)|0);}return new l.init(o,p)}});var m=a.enc={};var h=m.Hex={stringify:function(p){var r=p.words;var o=p.sigBytes;var q=[];for(var n=0;n<o;n++){var s=(r[n>>>2]>>>(24-(n%4)*8))&255;q.push((s>>>4).toString(16));q.push((s&15).toString(16));}return q.join("")},parse:function(p){var n=p.length;var q=[];for(var o=0;o<n;o+=2){q[o>>>3]|=parseInt(p.substr(o,2),16)<<(24-(o%8)*4);}return new l.init(q,n/2)}};var d=m.Latin1={stringify:function(q){var r=q.words;var p=q.sigBytes;var n=[];for(var o=0;o<p;o++){var s=(r[o>>>2]>>>(24-(o%4)*8))&255;n.push(String.fromCharCode(s));}return n.join("")},parse:function(p){var n=p.length;var q=[];for(var o=0;o<n;o++){q[o>>>2]|=(p.charCodeAt(o)&255)<<(24-(o%4)*8);}return new l.init(q,n)}};var c=m.Utf8={stringify:function(n){try{return decodeURIComponent(escape(d.stringify(n)))}catch(o){throw new Error("Malformed UTF-8 data")}},parse:function(n){return d.parse(unescape(encodeURIComponent(n)))}};var i=b.BufferedBlockAlgorithm=j.extend({reset:function(){this._data=new l.init();this._nDataBytes=0;},_append:function(n){if(typeof n=="string"){n=c.parse(n);}this._data.concat(n);this._nDataBytes+=n.sigBytes;},_process:function(w){var q=this._data;var x=q.words;var n=q.sigBytes;var t=this.blockSize;var v=t*4;var u=n/v;if(w){u=e.ceil(u);}else {u=e.max((u|0)-this._minBufferSize,0);}var s=u*t;var r=e.min(s*4,n);if(s){for(var p=0;p<s;p+=t){this._doProcessBlock(x,p);}var o=x.splice(0,s);q.sigBytes-=r;}return new l.init(o,r)},clone:function(){var n=j.clone.call(this);n._data=this._data.clone();return n},_minBufferSize:0});b.Hasher=i.extend({cfg:j.extend(),init:function(n){this.cfg=this.cfg.extend(n);this.reset();},reset:function(){i.reset.call(this);this._doReset();},update:function(n){this._append(n);this._process();return this},finalize:function(n){if(n){this._append(n);}var o=this._doFinalize();return o},blockSize:512/32,_createHelper:function(n){return function(p,o){return new n.init(o).finalize(p)}},_createHmacHelper:function(n){return function(p,o){return new k.HMAC.init(n,o).finalize(p)}}});var k=a.algo={};return a}(Math));
    /*
    CryptoJS v3.1.2 x64-core-min.js
    code.google.com/p/crypto-js
    (c) 2009-2013 by Jeff Mott. All rights reserved.
    code.google.com/p/crypto-js/wiki/License
    */
    (function(g){var a=CryptoJS,f=a.lib,e=f.Base,h=f.WordArray,a=a.x64={};a.Word=e.extend({init:function(b,c){this.high=b;this.low=c;}});a.WordArray=e.extend({init:function(b,c){b=this.words=b||[];this.sigBytes=c!=g?c:8*b.length;},toX32:function(){for(var b=this.words,c=b.length,a=[],d=0;d<c;d++){var e=b[d];a.push(e.high);a.push(e.low);}return h.create(a,this.sigBytes)},clone:function(){for(var b=e.clone.call(this),c=b.words=this.words.slice(0),a=c.length,d=0;d<a;d++)c[d]=c[d].clone();return b}});})();

    /*
    CryptoJS v3.1.2 cipher-core.js
    code.google.com/p/crypto-js
    (c) 2009-2013 by Jeff Mott. All rights reserved.
    code.google.com/p/crypto-js/wiki/License
    */
    CryptoJS.lib.Cipher||function(u){var g=CryptoJS,f=g.lib,k=f.Base,l=f.WordArray,q=f.BufferedBlockAlgorithm,r=g.enc.Base64,v=g.algo.EvpKDF,n=f.Cipher=q.extend({cfg:k.extend(),createEncryptor:function(a,b){return this.create(this._ENC_XFORM_MODE,a,b)},createDecryptor:function(a,b){return this.create(this._DEC_XFORM_MODE,a,b)},init:function(a,b,c){this.cfg=this.cfg.extend(c);this._xformMode=a;this._key=b;this.reset();},reset:function(){q.reset.call(this);this._doReset();},process:function(a){this._append(a);
    return this._process()},finalize:function(a){a&&this._append(a);return this._doFinalize()},keySize:4,ivSize:4,_ENC_XFORM_MODE:1,_DEC_XFORM_MODE:2,_createHelper:function(a){return {encrypt:function(b,c,d){return ("string"==typeof c?s:j).encrypt(a,b,c,d)},decrypt:function(b,c,d){return ("string"==typeof c?s:j).decrypt(a,b,c,d)}}}});f.StreamCipher=n.extend({_doFinalize:function(){return this._process(!0)},blockSize:1});var m=g.mode={},t=function(a,b,c){var d=this._iv;d?this._iv=u:d=this._prevBlock;for(var e=
    0;e<c;e++)a[b+e]^=d[e];},h=(f.BlockCipherMode=k.extend({createEncryptor:function(a,b){return this.Encryptor.create(a,b)},createDecryptor:function(a,b){return this.Decryptor.create(a,b)},init:function(a,b){this._cipher=a;this._iv=b;}})).extend();h.Encryptor=h.extend({processBlock:function(a,b){var c=this._cipher,d=c.blockSize;t.call(this,a,b,d);c.encryptBlock(a,b);this._prevBlock=a.slice(b,b+d);}});h.Decryptor=h.extend({processBlock:function(a,b){var c=this._cipher,d=c.blockSize,e=a.slice(b,b+d);c.decryptBlock(a,
    b);t.call(this,a,b,d);this._prevBlock=e;}});m=m.CBC=h;h=(g.pad={}).Pkcs7={pad:function(a,b){for(var c=4*b,c=c-a.sigBytes%c,d=c<<24|c<<16|c<<8|c,e=[],f=0;f<c;f+=4)e.push(d);c=l.create(e,c);a.concat(c);},unpad:function(a){a.sigBytes-=a.words[a.sigBytes-1>>>2]&255;}};f.BlockCipher=n.extend({cfg:n.cfg.extend({mode:m,padding:h}),reset:function(){n.reset.call(this);var a=this.cfg,b=a.iv,a=a.mode;if(this._xformMode==this._ENC_XFORM_MODE)var c=a.createEncryptor;else c=a.createDecryptor,this._minBufferSize=1;
    this._mode=c.call(a,this,b&&b.words);},_doProcessBlock:function(a,b){this._mode.processBlock(a,b);},_doFinalize:function(){var a=this.cfg.padding;if(this._xformMode==this._ENC_XFORM_MODE){a.pad(this._data,this.blockSize);var b=this._process(!0);}else b=this._process(!0),a.unpad(b);return b},blockSize:4});var p=f.CipherParams=k.extend({init:function(a){this.mixIn(a);},toString:function(a){return (a||this.formatter).stringify(this)}}),m=(g.format={}).OpenSSL={stringify:function(a){var b=a.ciphertext;a=a.salt;
    return (a?l.create([1398893684,1701076831]).concat(a).concat(b):b).toString(r)},parse:function(a){a=r.parse(a);var b=a.words;if(1398893684==b[0]&&1701076831==b[1]){var c=l.create(b.slice(2,4));b.splice(0,4);a.sigBytes-=16;}return p.create({ciphertext:a,salt:c})}},j=f.SerializableCipher=k.extend({cfg:k.extend({format:m}),encrypt:function(a,b,c,d){d=this.cfg.extend(d);var e=a.createEncryptor(c,d);b=e.finalize(b);e=e.cfg;return p.create({ciphertext:b,key:c,iv:e.iv,algorithm:a,mode:e.mode,padding:e.padding,
    blockSize:a.blockSize,formatter:d.format})},decrypt:function(a,b,c,d){d=this.cfg.extend(d);b=this._parse(b,d.format);return a.createDecryptor(c,d).finalize(b.ciphertext)},_parse:function(a,b){return "string"==typeof a?b.parse(a,this):a}}),g=(g.kdf={}).OpenSSL={execute:function(a,b,c,d){d||(d=l.random(8));a=v.create({keySize:b+c}).compute(a,d);c=l.create(a.words.slice(b),4*c);a.sigBytes=4*b;return p.create({key:a,iv:c,salt:d})}},s=f.PasswordBasedCipher=j.extend({cfg:j.cfg.extend({kdf:g}),encrypt:function(a,
    b,c,d){d=this.cfg.extend(d);c=d.kdf.execute(c,a.keySize,a.ivSize);d.iv=c.iv;a=j.encrypt.call(this,a,b,c.key,d);a.mixIn(c);return a},decrypt:function(a,b,c,d){d=this.cfg.extend(d);b=this._parse(b,d.format);c=d.kdf.execute(c,a.keySize,a.ivSize,b.salt);d.iv=c.iv;return j.decrypt.call(this,a,b,c.key,d)}});}();

    /*
    CryptoJS v3.1.2 enc-base64.js
    code.google.com/p/crypto-js
    (c) 2009-2013 by Jeff Mott. All rights reserved.
    code.google.com/p/crypto-js/wiki/License
    */
    (function(){var h=CryptoJS,j=h.lib.WordArray;h.enc.Base64={stringify:function(b){var e=b.words,f=b.sigBytes,c=this._map;b.clamp();b=[];for(var a=0;a<f;a+=3)for(var d=(e[a>>>2]>>>24-8*(a%4)&255)<<16|(e[a+1>>>2]>>>24-8*((a+1)%4)&255)<<8|e[a+2>>>2]>>>24-8*((a+2)%4)&255,g=0;4>g&&a+0.75*g<f;g++)b.push(c.charAt(d>>>6*(3-g)&63));if(e=c.charAt(64))for(;b.length%4;)b.push(e);return b.join("")},parse:function(b){var e=b.length,f=this._map,c=f.charAt(64);c&&(c=b.indexOf(c),-1!=c&&(e=c));for(var c=[],a=0,d=0;d<
    e;d++)if(d%4){var g=f.indexOf(b.charAt(d-1))<<2*(d%4),h=f.indexOf(b.charAt(d))>>>6-2*(d%4);c[a>>>2]|=(g|h)<<24-8*(a%4);a++;}return j.create(c,a)},_map:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="};})();

    /*
    CryptoJS v3.1.2 sha1-min.js
    code.google.com/p/crypto-js
    (c) 2009-2013 by Jeff Mott. All rights reserved.
    code.google.com/p/crypto-js/wiki/License
    */
    (function(){var k=CryptoJS,b=k.lib,m=b.WordArray,l=b.Hasher,d=[],b=k.algo.SHA1=l.extend({_doReset:function(){this._hash=new m.init([1732584193,4023233417,2562383102,271733878,3285377520]);},_doProcessBlock:function(n,p){for(var a=this._hash.words,e=a[0],f=a[1],h=a[2],j=a[3],b=a[4],c=0;80>c;c++){if(16>c)d[c]=n[p+c]|0;else {var g=d[c-3]^d[c-8]^d[c-14]^d[c-16];d[c]=g<<1|g>>>31;}g=(e<<5|e>>>27)+b+d[c];g=20>c?g+((f&h|~f&j)+1518500249):40>c?g+((f^h^j)+1859775393):60>c?g+((f&h|f&j|h&j)-1894007588):g+((f^h^
    j)-899497514);b=j;j=h;h=f<<30|f>>>2;f=e;e=g;}a[0]=a[0]+e|0;a[1]=a[1]+f|0;a[2]=a[2]+h|0;a[3]=a[3]+j|0;a[4]=a[4]+b|0;},_doFinalize:function(){var b=this._data,d=b.words,a=8*this._nDataBytes,e=8*b.sigBytes;d[e>>>5]|=128<<24-e%32;d[(e+64>>>9<<4)+14]=Math.floor(a/4294967296);d[(e+64>>>9<<4)+15]=a;b.sigBytes=4*d.length;this._process();return this._hash},clone:function(){var b=l.clone.call(this);b._hash=this._hash.clone();return b}});k.SHA1=l._createHelper(b);k.HmacSHA1=l._createHmacHelper(b);})();

    /*
    CryptoJS v3.1.2 sha256-min.js
    code.google.com/p/crypto-js
    (c) 2009-2013 by Jeff Mott. All rights reserved.
    code.google.com/p/crypto-js/wiki/License
    */
    (function(k){for(var g=CryptoJS,h=g.lib,v=h.WordArray,j=h.Hasher,h=g.algo,s=[],t=[],u=function(q){return 4294967296*(q-(q|0))|0},l=2,b=0;64>b;){var d;a:{d=l;for(var w=k.sqrt(d),r=2;r<=w;r++)if(!(d%r)){d=!1;break a}d=!0;}d&&(8>b&&(s[b]=u(k.pow(l,0.5))),t[b]=u(k.pow(l,1/3)),b++);l++;}var n=[],h=h.SHA256=j.extend({_doReset:function(){this._hash=new v.init(s.slice(0));},_doProcessBlock:function(q,h){for(var a=this._hash.words,c=a[0],d=a[1],b=a[2],k=a[3],f=a[4],g=a[5],j=a[6],l=a[7],e=0;64>e;e++){if(16>e)n[e]=
    q[h+e]|0;else {var m=n[e-15],p=n[e-2];n[e]=((m<<25|m>>>7)^(m<<14|m>>>18)^m>>>3)+n[e-7]+((p<<15|p>>>17)^(p<<13|p>>>19)^p>>>10)+n[e-16];}m=l+((f<<26|f>>>6)^(f<<21|f>>>11)^(f<<7|f>>>25))+(f&g^~f&j)+t[e]+n[e];p=((c<<30|c>>>2)^(c<<19|c>>>13)^(c<<10|c>>>22))+(c&d^c&b^d&b);l=j;j=g;g=f;f=k+m|0;k=b;b=d;d=c;c=m+p|0;}a[0]=a[0]+c|0;a[1]=a[1]+d|0;a[2]=a[2]+b|0;a[3]=a[3]+k|0;a[4]=a[4]+f|0;a[5]=a[5]+g|0;a[6]=a[6]+j|0;a[7]=a[7]+l|0;},_doFinalize:function(){var d=this._data,b=d.words,a=8*this._nDataBytes,c=8*d.sigBytes;
    b[c>>>5]|=128<<24-c%32;b[(c+64>>>9<<4)+14]=k.floor(a/4294967296);b[(c+64>>>9<<4)+15]=a;d.sigBytes=4*b.length;this._process();return this._hash},clone:function(){var b=j.clone.call(this);b._hash=this._hash.clone();return b}});g.SHA256=j._createHelper(h);g.HmacSHA256=j._createHmacHelper(h);})(Math);

    /*
    CryptoJS v3.1.2 sha512-min.js
    code.google.com/p/crypto-js
    (c) 2009-2013 by Jeff Mott. All rights reserved.
    code.google.com/p/crypto-js/wiki/License
    */
    (function(){function a(){return d.create.apply(d,arguments)}for(var n=CryptoJS,r=n.lib.Hasher,e=n.x64,d=e.Word,T=e.WordArray,e=n.algo,ea=[a(1116352408,3609767458),a(1899447441,602891725),a(3049323471,3964484399),a(3921009573,2173295548),a(961987163,4081628472),a(1508970993,3053834265),a(2453635748,2937671579),a(2870763221,3664609560),a(3624381080,2734883394),a(310598401,1164996542),a(607225278,1323610764),a(1426881987,3590304994),a(1925078388,4068182383),a(2162078206,991336113),a(2614888103,633803317),
    a(3248222580,3479774868),a(3835390401,2666613458),a(4022224774,944711139),a(264347078,2341262773),a(604807628,2007800933),a(770255983,1495990901),a(1249150122,1856431235),a(1555081692,3175218132),a(1996064986,2198950837),a(2554220882,3999719339),a(2821834349,766784016),a(2952996808,2566594879),a(3210313671,3203337956),a(3336571891,1034457026),a(3584528711,2466948901),a(113926993,3758326383),a(338241895,168717936),a(666307205,1188179964),a(773529912,1546045734),a(1294757372,1522805485),a(1396182291,
    2643833823),a(1695183700,2343527390),a(1986661051,1014477480),a(2177026350,1206759142),a(2456956037,344077627),a(2730485921,1290863460),a(2820302411,3158454273),a(3259730800,3505952657),a(3345764771,106217008),a(3516065817,3606008344),a(3600352804,1432725776),a(4094571909,1467031594),a(275423344,851169720),a(430227734,3100823752),a(506948616,1363258195),a(659060556,3750685593),a(883997877,3785050280),a(958139571,3318307427),a(1322822218,3812723403),a(1537002063,2003034995),a(1747873779,3602036899),
    a(1955562222,1575990012),a(2024104815,1125592928),a(2227730452,2716904306),a(2361852424,442776044),a(2428436474,593698344),a(2756734187,3733110249),a(3204031479,2999351573),a(3329325298,3815920427),a(3391569614,3928383900),a(3515267271,566280711),a(3940187606,3454069534),a(4118630271,4000239992),a(116418474,1914138554),a(174292421,2731055270),a(289380356,3203993006),a(460393269,320620315),a(685471733,587496836),a(852142971,1086792851),a(1017036298,365543100),a(1126000580,2618297676),a(1288033470,
    3409855158),a(1501505948,4234509866),a(1607167915,987167468),a(1816402316,1246189591)],v=[],w=0;80>w;w++)v[w]=a();e=e.SHA512=r.extend({_doReset:function(){this._hash=new T.init([new d.init(1779033703,4089235720),new d.init(3144134277,2227873595),new d.init(1013904242,4271175723),new d.init(2773480762,1595750129),new d.init(1359893119,2917565137),new d.init(2600822924,725511199),new d.init(528734635,4215389547),new d.init(1541459225,327033209)]);},_doProcessBlock:function(a,d){for(var f=this._hash.words,
    F=f[0],e=f[1],n=f[2],r=f[3],G=f[4],H=f[5],I=f[6],f=f[7],w=F.high,J=F.low,X=e.high,K=e.low,Y=n.high,L=n.low,Z=r.high,M=r.low,$=G.high,N=G.low,aa=H.high,O=H.low,ba=I.high,P=I.low,ca=f.high,Q=f.low,k=w,g=J,z=X,x=K,A=Y,y=L,U=Z,B=M,l=$,h=N,R=aa,C=O,S=ba,D=P,V=ca,E=Q,m=0;80>m;m++){var s=v[m];if(16>m)var j=s.high=a[d+2*m]|0,b=s.low=a[d+2*m+1]|0;else {var j=v[m-15],b=j.high,p=j.low,j=(b>>>1|p<<31)^(b>>>8|p<<24)^b>>>7,p=(p>>>1|b<<31)^(p>>>8|b<<24)^(p>>>7|b<<25),u=v[m-2],b=u.high,c=u.low,u=(b>>>19|c<<13)^(b<<
    3|c>>>29)^b>>>6,c=(c>>>19|b<<13)^(c<<3|b>>>29)^(c>>>6|b<<26),b=v[m-7],W=b.high,t=v[m-16],q=t.high,t=t.low,b=p+b.low,j=j+W+(b>>>0<p>>>0?1:0),b=b+c,j=j+u+(b>>>0<c>>>0?1:0),b=b+t,j=j+q+(b>>>0<t>>>0?1:0);s.high=j;s.low=b;}var W=l&R^~l&S,t=h&C^~h&D,s=k&z^k&A^z&A,T=g&x^g&y^x&y,p=(k>>>28|g<<4)^(k<<30|g>>>2)^(k<<25|g>>>7),u=(g>>>28|k<<4)^(g<<30|k>>>2)^(g<<25|k>>>7),c=ea[m],fa=c.high,da=c.low,c=E+((h>>>14|l<<18)^(h>>>18|l<<14)^(h<<23|l>>>9)),q=V+((l>>>14|h<<18)^(l>>>18|h<<14)^(l<<23|h>>>9))+(c>>>0<E>>>0?1:
    0),c=c+t,q=q+W+(c>>>0<t>>>0?1:0),c=c+da,q=q+fa+(c>>>0<da>>>0?1:0),c=c+b,q=q+j+(c>>>0<b>>>0?1:0),b=u+T,s=p+s+(b>>>0<u>>>0?1:0),V=S,E=D,S=R,D=C,R=l,C=h,h=B+c|0,l=U+q+(h>>>0<B>>>0?1:0)|0,U=A,B=y,A=z,y=x,z=k,x=g,g=c+b|0,k=q+s+(g>>>0<c>>>0?1:0)|0;}J=F.low=J+g;F.high=w+k+(J>>>0<g>>>0?1:0);K=e.low=K+x;e.high=X+z+(K>>>0<x>>>0?1:0);L=n.low=L+y;n.high=Y+A+(L>>>0<y>>>0?1:0);M=r.low=M+B;r.high=Z+U+(M>>>0<B>>>0?1:0);N=G.low=N+h;G.high=$+l+(N>>>0<h>>>0?1:0);O=H.low=O+C;H.high=aa+R+(O>>>0<C>>>0?1:0);P=I.low=P+D;
    I.high=ba+S+(P>>>0<D>>>0?1:0);Q=f.low=Q+E;f.high=ca+V+(Q>>>0<E>>>0?1:0);},_doFinalize:function(){var a=this._data,d=a.words,f=8*this._nDataBytes,e=8*a.sigBytes;d[e>>>5]|=128<<24-e%32;d[(e+128>>>10<<5)+30]=Math.floor(f/4294967296);d[(e+128>>>10<<5)+31]=f;a.sigBytes=4*d.length;this._process();return this._hash.toX32()},clone:function(){var a=r.clone.call(this);a._hash=this._hash.clone();return a},blockSize:32});n.SHA512=r._createHelper(e);n.HmacSHA512=r._createHmacHelper(e);})();

    /*
    CryptoJS v3.1.2 sha384-min.js
    code.google.com/p/crypto-js
    (c) 2009-2013 by Jeff Mott. All rights reserved.
    code.google.com/p/crypto-js/wiki/License
    */
    (function(){var c=CryptoJS,a=c.x64,b=a.Word,e=a.WordArray,a=c.algo,d=a.SHA512,a=a.SHA384=d.extend({_doReset:function(){this._hash=new e.init([new b.init(3418070365,3238371032),new b.init(1654270250,914150663),new b.init(2438529370,812702999),new b.init(355462360,4144912697),new b.init(1731405415,4290775857),new b.init(2394180231,1750603025),new b.init(3675008525,1694076839),new b.init(1203062813,3204075428)]);},_doFinalize:function(){var a=d._doFinalize.call(this);a.sigBytes-=16;return a}});c.SHA384=
    d._createHelper(a);c.HmacSHA384=d._createHmacHelper(a);})();

    /*
    CryptoJS v3.1.2 hmac.js
    code.google.com/p/crypto-js
    (c) 2009-2013 by Jeff Mott. All rights reserved.
    code.google.com/p/crypto-js/wiki/License
    */
    (function(){var c=CryptoJS,k=c.enc.Utf8;c.algo.HMAC=c.lib.Base.extend({init:function(a,b){a=this._hasher=new a.init;"string"==typeof b&&(b=k.parse(b));var c=a.blockSize,e=4*c;b.sigBytes>e&&(b=a.finalize(b));b.clamp();for(var f=this._oKey=b.clone(),g=this._iKey=b.clone(),h=f.words,j=g.words,d=0;d<c;d++)h[d]^=1549556828,j[d]^=909522486;f.sigBytes=g.sigBytes=e;this.reset();},reset:function(){var a=this._hasher;a.reset();a.update(this._iKey);},update:function(a){this._hasher.update(a);return this},finalize:function(a){var b=
    this._hasher;a=b.finalize(a);b.reset();return b.finalize(this._oKey.clone().concat(a))}});})();

    /*! (c) Tom Wu | http://www-cs-students.stanford.edu/~tjw/jsbn/
     */
    var b64map="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";var b64pad="=";function hex2b64(d){var b;var e;var a="";for(b=0;b+3<=d.length;b+=3){e=parseInt(d.substring(b,b+3),16);a+=b64map.charAt(e>>6)+b64map.charAt(e&63);}if(b+1==d.length){e=parseInt(d.substring(b,b+1),16);a+=b64map.charAt(e<<2);}else {if(b+2==d.length){e=parseInt(d.substring(b,b+2),16);a+=b64map.charAt(e>>2)+b64map.charAt((e&3)<<4);}}{while((a.length&3)>0){a+=b64pad;}}return a}function b64tohex(f){var d="";var e;var b=0;var c;var a;for(e=0;e<f.length;++e){if(f.charAt(e)==b64pad){break}a=b64map.indexOf(f.charAt(e));if(a<0){continue}if(b==0){d+=int2char(a>>2);c=a&3;b=1;}else {if(b==1){d+=int2char((c<<2)|(a>>4));c=a&15;b=2;}else {if(b==2){d+=int2char(c);d+=int2char(a>>2);c=a&3;b=3;}else {d+=int2char((c<<2)|(a>>4));d+=int2char(a&15);b=0;}}}}if(b==1){d+=int2char(c<<2);}return d}/*! (c) Tom Wu | http://www-cs-students.stanford.edu/~tjw/jsbn/
     */
    var dbits;function BigInteger(e,d,f){if(e!=null){if("number"==typeof e){this.fromNumber(e,d,f);}else {if(d==null&&"string"!=typeof e){this.fromString(e,256);}else {this.fromString(e,d);}}}}function nbi(){return new BigInteger(null)}function am1(f,a,b,e,h,g){while(--g>=0){var d=a*this[f++]+b[e]+h;h=Math.floor(d/67108864);b[e++]=d&67108863;}return h}function am2(f,q,r,e,o,a){var k=q&32767,p=q>>15;while(--a>=0){var d=this[f]&32767;var g=this[f++]>>15;var b=p*d+g*k;d=k*d+((b&32767)<<15)+r[e]+(o&1073741823);o=(d>>>30)+(b>>>15)+p*g+(o>>>30);r[e++]=d&1073741823;}return o}function am3(f,q,r,e,o,a){var k=q&16383,p=q>>14;while(--a>=0){var d=this[f]&16383;var g=this[f++]>>14;var b=p*d+g*k;d=k*d+((b&16383)<<14)+r[e]+o;o=(d>>28)+(b>>14)+p*g;r[e++]=d&268435455;}return o}if((navigator.appName=="Microsoft Internet Explorer")){BigInteger.prototype.am=am2;dbits=30;}else {if((navigator.appName!="Netscape")){BigInteger.prototype.am=am1;dbits=26;}else {BigInteger.prototype.am=am3;dbits=28;}}BigInteger.prototype.DB=dbits;BigInteger.prototype.DM=((1<<dbits)-1);BigInteger.prototype.DV=(1<<dbits);var BI_FP=52;BigInteger.prototype.FV=Math.pow(2,BI_FP);BigInteger.prototype.F1=BI_FP-dbits;BigInteger.prototype.F2=2*dbits-BI_FP;var BI_RM="0123456789abcdefghijklmnopqrstuvwxyz";var BI_RC=new Array();var rr,vv;rr="0".charCodeAt(0);for(vv=0;vv<=9;++vv){BI_RC[rr++]=vv;}rr="a".charCodeAt(0);for(vv=10;vv<36;++vv){BI_RC[rr++]=vv;}rr="A".charCodeAt(0);for(vv=10;vv<36;++vv){BI_RC[rr++]=vv;}function int2char(a){return BI_RM.charAt(a)}function intAt(b,a){var d=BI_RC[b.charCodeAt(a)];return (d==null)?-1:d}function bnpCopyTo(b){for(var a=this.t-1;a>=0;--a){b[a]=this[a];}b.t=this.t;b.s=this.s;}function bnpFromInt(a){this.t=1;this.s=(a<0)?-1:0;if(a>0){this[0]=a;}else {if(a<-1){this[0]=a+this.DV;}else {this.t=0;}}}function nbv(a){var b=nbi();b.fromInt(a);return b}function bnpFromString(h,c){var e;if(c==16){e=4;}else {if(c==8){e=3;}else {if(c==256){e=8;}else {if(c==2){e=1;}else {if(c==32){e=5;}else {if(c==4){e=2;}else {this.fromRadix(h,c);return}}}}}}this.t=0;this.s=0;var g=h.length,d=false,f=0;while(--g>=0){var a=(e==8)?h[g]&255:intAt(h,g);if(a<0){if(h.charAt(g)=="-"){d=true;}continue}d=false;if(f==0){this[this.t++]=a;}else {if(f+e>this.DB){this[this.t-1]|=(a&((1<<(this.DB-f))-1))<<f;this[this.t++]=(a>>(this.DB-f));}else {this[this.t-1]|=a<<f;}}f+=e;if(f>=this.DB){f-=this.DB;}}if(e==8&&(h[0]&128)!=0){this.s=-1;if(f>0){this[this.t-1]|=((1<<(this.DB-f))-1)<<f;}}this.clamp();if(d){BigInteger.ZERO.subTo(this,this);}}function bnpClamp(){var a=this.s&this.DM;while(this.t>0&&this[this.t-1]==a){--this.t;}}function bnToString(c){if(this.s<0){return "-"+this.negate().toString(c)}var e;if(c==16){e=4;}else {if(c==8){e=3;}else {if(c==2){e=1;}else {if(c==32){e=5;}else {if(c==4){e=2;}else {return this.toRadix(c)}}}}}var g=(1<<e)-1,l,a=false,h="",f=this.t;var j=this.DB-(f*this.DB)%e;if(f-->0){if(j<this.DB&&(l=this[f]>>j)>0){a=true;h=int2char(l);}while(f>=0){if(j<e){l=(this[f]&((1<<j)-1))<<(e-j);l|=this[--f]>>(j+=this.DB-e);}else {l=(this[f]>>(j-=e))&g;if(j<=0){j+=this.DB;--f;}}if(l>0){a=true;}if(a){h+=int2char(l);}}}return a?h:"0"}function bnNegate(){var a=nbi();BigInteger.ZERO.subTo(this,a);return a}function bnAbs(){return (this.s<0)?this.negate():this}function bnCompareTo(b){var d=this.s-b.s;if(d!=0){return d}var c=this.t;d=c-b.t;if(d!=0){return (this.s<0)?-d:d}while(--c>=0){if((d=this[c]-b[c])!=0){return d}}return 0}function nbits(a){var c=1,b;if((b=a>>>16)!=0){a=b;c+=16;}if((b=a>>8)!=0){a=b;c+=8;}if((b=a>>4)!=0){a=b;c+=4;}if((b=a>>2)!=0){a=b;c+=2;}if((b=a>>1)!=0){a=b;c+=1;}return c}function bnBitLength(){if(this.t<=0){return 0}return this.DB*(this.t-1)+nbits(this[this.t-1]^(this.s&this.DM))}function bnpDLShiftTo(c,b){var a;for(a=this.t-1;a>=0;--a){b[a+c]=this[a];}for(a=c-1;a>=0;--a){b[a]=0;}b.t=this.t+c;b.s=this.s;}function bnpDRShiftTo(c,b){for(var a=c;a<this.t;++a){b[a-c]=this[a];}b.t=Math.max(this.t-c,0);b.s=this.s;}function bnpLShiftTo(j,e){var b=j%this.DB;var a=this.DB-b;var g=(1<<a)-1;var f=Math.floor(j/this.DB),h=(this.s<<b)&this.DM,d;for(d=this.t-1;d>=0;--d){e[d+f+1]=(this[d]>>a)|h;h=(this[d]&g)<<b;}for(d=f-1;d>=0;--d){e[d]=0;}e[f]=h;e.t=this.t+f+1;e.s=this.s;e.clamp();}function bnpRShiftTo(g,d){d.s=this.s;var e=Math.floor(g/this.DB);if(e>=this.t){d.t=0;return}var b=g%this.DB;var a=this.DB-b;var f=(1<<b)-1;d[0]=this[e]>>b;for(var c=e+1;c<this.t;++c){d[c-e-1]|=(this[c]&f)<<a;d[c-e]=this[c]>>b;}if(b>0){d[this.t-e-1]|=(this.s&f)<<a;}d.t=this.t-e;d.clamp();}function bnpSubTo(d,f){var e=0,g=0,b=Math.min(d.t,this.t);while(e<b){g+=this[e]-d[e];f[e++]=g&this.DM;g>>=this.DB;}if(d.t<this.t){g-=d.s;while(e<this.t){g+=this[e];f[e++]=g&this.DM;g>>=this.DB;}g+=this.s;}else {g+=this.s;while(e<d.t){g-=d[e];f[e++]=g&this.DM;g>>=this.DB;}g-=d.s;}f.s=(g<0)?-1:0;if(g<-1){f[e++]=this.DV+g;}else {if(g>0){f[e++]=g;}}f.t=e;f.clamp();}function bnpMultiplyTo(c,e){var b=this.abs(),f=c.abs();var d=b.t;e.t=d+f.t;while(--d>=0){e[d]=0;}for(d=0;d<f.t;++d){e[d+b.t]=b.am(0,f[d],e,d,0,b.t);}e.s=0;e.clamp();if(this.s!=c.s){BigInteger.ZERO.subTo(e,e);}}function bnpSquareTo(d){var a=this.abs();var b=d.t=2*a.t;while(--b>=0){d[b]=0;}for(b=0;b<a.t-1;++b){var e=a.am(b,a[b],d,2*b,0,1);if((d[b+a.t]+=a.am(b+1,2*a[b],d,2*b+1,e,a.t-b-1))>=a.DV){d[b+a.t]-=a.DV;d[b+a.t+1]=1;}}if(d.t>0){d[d.t-1]+=a.am(b,a[b],d,2*b,0,1);}d.s=0;d.clamp();}function bnpDivRemTo(n,h,g){var w=n.abs();if(w.t<=0){return}var k=this.abs();if(k.t<w.t){if(h!=null){h.fromInt(0);}if(g!=null){this.copyTo(g);}return}if(g==null){g=nbi();}var d=nbi(),a=this.s,l=n.s;var v=this.DB-nbits(w[w.t-1]);if(v>0){w.lShiftTo(v,d);k.lShiftTo(v,g);}else {w.copyTo(d);k.copyTo(g);}var p=d.t;var b=d[p-1];if(b==0){return}var o=b*(1<<this.F1)+((p>1)?d[p-2]>>this.F2:0);var A=this.FV/o,z=(1<<this.F1)/o,x=1<<this.F2;var u=g.t,s=u-p,f=(h==null)?nbi():h;d.dlShiftTo(s,f);if(g.compareTo(f)>=0){g[g.t++]=1;g.subTo(f,g);}BigInteger.ONE.dlShiftTo(p,f);f.subTo(d,d);while(d.t<p){d[d.t++]=0;}while(--s>=0){var c=(g[--u]==b)?this.DM:Math.floor(g[u]*A+(g[u-1]+x)*z);if((g[u]+=d.am(0,c,g,s,0,p))<c){d.dlShiftTo(s,f);g.subTo(f,g);while(g[u]<--c){g.subTo(f,g);}}}if(h!=null){g.drShiftTo(p,h);if(a!=l){BigInteger.ZERO.subTo(h,h);}}g.t=p;g.clamp();if(v>0){g.rShiftTo(v,g);}if(a<0){BigInteger.ZERO.subTo(g,g);}}function bnMod(b){var c=nbi();this.abs().divRemTo(b,null,c);if(this.s<0&&c.compareTo(BigInteger.ZERO)>0){b.subTo(c,c);}return c}function Classic(a){this.m=a;}function cConvert(a){if(a.s<0||a.compareTo(this.m)>=0){return a.mod(this.m)}else {return a}}function cRevert(a){return a}function cReduce(a){a.divRemTo(this.m,null,a);}function cMulTo(a,c,b){a.multiplyTo(c,b);this.reduce(b);}function cSqrTo(a,b){a.squareTo(b);this.reduce(b);}Classic.prototype.convert=cConvert;Classic.prototype.revert=cRevert;Classic.prototype.reduce=cReduce;Classic.prototype.mulTo=cMulTo;Classic.prototype.sqrTo=cSqrTo;function bnpInvDigit(){if(this.t<1){return 0}var a=this[0];if((a&1)==0){return 0}var b=a&3;b=(b*(2-(a&15)*b))&15;b=(b*(2-(a&255)*b))&255;b=(b*(2-(((a&65535)*b)&65535)))&65535;b=(b*(2-a*b%this.DV))%this.DV;return (b>0)?this.DV-b:-b}function Montgomery(a){this.m=a;this.mp=a.invDigit();this.mpl=this.mp&32767;this.mph=this.mp>>15;this.um=(1<<(a.DB-15))-1;this.mt2=2*a.t;}function montConvert(a){var b=nbi();a.abs().dlShiftTo(this.m.t,b);b.divRemTo(this.m,null,b);if(a.s<0&&b.compareTo(BigInteger.ZERO)>0){this.m.subTo(b,b);}return b}function montRevert(a){var b=nbi();a.copyTo(b);this.reduce(b);return b}function montReduce(a){while(a.t<=this.mt2){a[a.t++]=0;}for(var c=0;c<this.m.t;++c){var b=a[c]&32767;var d=(b*this.mpl+(((b*this.mph+(a[c]>>15)*this.mpl)&this.um)<<15))&a.DM;b=c+this.m.t;a[b]+=this.m.am(0,d,a,c,0,this.m.t);while(a[b]>=a.DV){a[b]-=a.DV;a[++b]++;}}a.clamp();a.drShiftTo(this.m.t,a);if(a.compareTo(this.m)>=0){a.subTo(this.m,a);}}function montSqrTo(a,b){a.squareTo(b);this.reduce(b);}function montMulTo(a,c,b){a.multiplyTo(c,b);this.reduce(b);}Montgomery.prototype.convert=montConvert;Montgomery.prototype.revert=montRevert;Montgomery.prototype.reduce=montReduce;Montgomery.prototype.mulTo=montMulTo;Montgomery.prototype.sqrTo=montSqrTo;function bnpIsEven(){return ((this.t>0)?(this[0]&1):this.s)==0}function bnpExp(h,j){if(h>4294967295||h<1){return BigInteger.ONE}var f=nbi(),a=nbi(),d=j.convert(this),c=nbits(h)-1;d.copyTo(f);while(--c>=0){j.sqrTo(f,a);if((h&(1<<c))>0){j.mulTo(a,d,f);}else {var b=f;f=a;a=b;}}return j.revert(f)}function bnModPowInt(b,a){var c;if(b<256||a.isEven()){c=new Classic(a);}else {c=new Montgomery(a);}return this.exp(b,c)}BigInteger.prototype.copyTo=bnpCopyTo;BigInteger.prototype.fromInt=bnpFromInt;BigInteger.prototype.fromString=bnpFromString;BigInteger.prototype.clamp=bnpClamp;BigInteger.prototype.dlShiftTo=bnpDLShiftTo;BigInteger.prototype.drShiftTo=bnpDRShiftTo;BigInteger.prototype.lShiftTo=bnpLShiftTo;BigInteger.prototype.rShiftTo=bnpRShiftTo;BigInteger.prototype.subTo=bnpSubTo;BigInteger.prototype.multiplyTo=bnpMultiplyTo;BigInteger.prototype.squareTo=bnpSquareTo;BigInteger.prototype.divRemTo=bnpDivRemTo;BigInteger.prototype.invDigit=bnpInvDigit;BigInteger.prototype.isEven=bnpIsEven;BigInteger.prototype.exp=bnpExp;BigInteger.prototype.toString=bnToString;BigInteger.prototype.negate=bnNegate;BigInteger.prototype.abs=bnAbs;BigInteger.prototype.compareTo=bnCompareTo;BigInteger.prototype.bitLength=bnBitLength;BigInteger.prototype.mod=bnMod;BigInteger.prototype.modPowInt=bnModPowInt;BigInteger.ZERO=nbv(0);BigInteger.ONE=nbv(1);
    /*! (c) Tom Wu | http://www-cs-students.stanford.edu/~tjw/jsbn/
     */
    function Arcfour(){this.i=0;this.j=0;this.S=new Array();}function ARC4init(d){var c,a,b;for(c=0;c<256;++c){this.S[c]=c;}a=0;for(c=0;c<256;++c){a=(a+this.S[c]+d[c%d.length])&255;b=this.S[c];this.S[c]=this.S[a];this.S[a]=b;}this.i=0;this.j=0;}function ARC4next(){var a;this.i=(this.i+1)&255;this.j=(this.j+this.S[this.i])&255;a=this.S[this.i];this.S[this.i]=this.S[this.j];this.S[this.j]=a;return this.S[(a+this.S[this.i])&255]}Arcfour.prototype.init=ARC4init;Arcfour.prototype.next=ARC4next;function prng_newstate(){return new Arcfour()}var rng_psize=256;
    /*! (c) Tom Wu | http://www-cs-students.stanford.edu/~tjw/jsbn/
     */
    var rng_state;var rng_pool;var rng_pptr;function rng_seed_int(a){rng_pool[rng_pptr++]^=a&255;rng_pool[rng_pptr++]^=(a>>8)&255;rng_pool[rng_pptr++]^=(a>>16)&255;rng_pool[rng_pptr++]^=(a>>24)&255;if(rng_pptr>=rng_psize){rng_pptr-=rng_psize;}}function rng_seed_time(){rng_seed_int(new Date().getTime());}if(rng_pool==null){rng_pool=new Array();rng_pptr=0;var t;if(window!==undefined&&(window.crypto!==undefined||window.msCrypto!==undefined)){var crypto=window.crypto||window.msCrypto;if(crypto.getRandomValues){var ua=new Uint8Array(32);crypto.getRandomValues(ua);for(t=0;t<32;++t){rng_pool[rng_pptr++]=ua[t];}}else {if(navigator.appName=="Netscape"&&navigator.appVersion<"5"){var z=window.crypto.random(32);for(t=0;t<z.length;++t){rng_pool[rng_pptr++]=z.charCodeAt(t)&255;}}}}while(rng_pptr<rng_psize){t=Math.floor(65536*Math.random());rng_pool[rng_pptr++]=t>>>8;rng_pool[rng_pptr++]=t&255;}rng_pptr=0;rng_seed_time();}function rng_get_byte(){if(rng_state==null){rng_seed_time();rng_state=prng_newstate();rng_state.init(rng_pool);for(rng_pptr=0;rng_pptr<rng_pool.length;++rng_pptr){rng_pool[rng_pptr]=0;}rng_pptr=0;}return rng_state.next()}function rng_get_bytes(b){var a;for(a=0;a<b.length;++a){b[a]=rng_get_byte();}}function SecureRandom(){}SecureRandom.prototype.nextBytes=rng_get_bytes;
    /*! Mike Samuel (c) 2009 | code.google.com/p/json-sans-eval
     */
    var jsonParse=(function(){var e="(?:-?\\b(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?(?:[eE][+-]?[0-9]+)?\\b)";var j='(?:[^\\0-\\x08\\x0a-\\x1f"\\\\]|\\\\(?:["/\\\\bfnrt]|u[0-9A-Fa-f]{4}))';var i='(?:"'+j+'*")';var d=new RegExp("(?:false|true|null|[\\{\\}\\[\\]]|"+e+"|"+i+")","g");var k=new RegExp("\\\\(?:([^u])|u(.{4}))","g");var g={'"':'"',"/":"/","\\":"\\",b:"\b",f:"\f",n:"\n",r:"\r",t:"\t"};function h(l,m,n){return m?g[m]:String.fromCharCode(parseInt(n,16))}var c=new String("");var a="\\";var b=Object.hasOwnProperty;return function(u,q){var p=u.match(d);var x;var v=p[0];var l=false;if("{"===v){x={};}else {if("["===v){x=[];}else {x=[];l=true;}}var t;var r=[x];for(var o=1-l,m=p.length;o<m;++o){v=p[o];var w;switch(v.charCodeAt(0)){default:w=r[0];w[t||w.length]=+(v);t=void 0;break;case 34:v=v.substring(1,v.length-1);if(v.indexOf(a)!==-1){v=v.replace(k,h);}w=r[0];if(!t){if(w instanceof Array){t=w.length;}else {t=v||c;break}}w[t]=v;t=void 0;break;case 91:w=r[0];r.unshift(w[t||w.length]=[]);t=void 0;break;case 93:r.shift();break;case 102:w=r[0];w[t||w.length]=false;t=void 0;break;case 110:w=r[0];w[t||w.length]=null;t=void 0;break;case 116:w=r[0];w[t||w.length]=true;t=void 0;break;case 123:w=r[0];r.unshift(w[t||w.length]={});t=void 0;break;case 125:r.shift();break}}if(l){if(r.length!==1){throw new Error()}x=x[0];}else {if(r.length){throw new Error()}}if(q){var s=function(C,B){var D=C[B];if(D&&typeof D==="object"){var n=null;for(var z in D){if(b.call(D,z)&&D!==C){var y=s(D,z);if(y!==void 0){D[z]=y;}else {if(!n){n=[];}n.push(z);}}}if(n){for(var A=n.length;--A>=0;){delete D[n[A]];}}}return q.call(C,B,D)};x=s({"":x},"");}return x}})();
    var KJUR;if(typeof KJUR=="undefined"||!KJUR){KJUR={};}if(typeof KJUR.lang=="undefined"||!KJUR.lang){KJUR.lang={};}KJUR.lang.String=function(){};function stoBA(d){var b=new Array();for(var c=0;c<d.length;c++){b[c]=d.charCodeAt(c);}return b}function BAtohex(b){var e="";for(var d=0;d<b.length;d++){var c=b[d].toString(16);if(c.length==1){c="0"+c;}e=e+c;}return e}function stohex(a){return BAtohex(stoBA(a))}function b64tob64u(a){a=a.replace(/\=/g,"");a=a.replace(/\+/g,"-");a=a.replace(/\//g,"_");return a}function b64utob64(a){if(a.length%4==2){a=a+"==";}else {if(a.length%4==3){a=a+"=";}}a=a.replace(/-/g,"+");a=a.replace(/_/g,"/");return a}function hextob64u(a){if(a.length%2==1){a="0"+a;}return b64tob64u(hex2b64(a))}function b64utohex(a){return b64tohex(b64utob64(a))}var utf8tob64u,b64utoutf8;if(typeof Buffer==="function"){utf8tob64u=function(a){return b64tob64u(new Buffer(a,"utf8").toString("base64"))};b64utoutf8=function(a){return new Buffer(b64utob64(a),"base64").toString("utf8")};}else {utf8tob64u=function(a){return hextob64u(uricmptohex(encodeURIComponentAll(a)))};b64utoutf8=function(a){return decodeURIComponent(hextouricmp(b64utohex(a)))};}function utf8tohex(a){return uricmptohex(encodeURIComponentAll(a))}function rstrtohex(c){var a="";for(var b=0;b<c.length;b++){a+=("0"+c.charCodeAt(b).toString(16)).slice(-2);}return a}function zulutomsec(n){var l,j,m,e,f,i,b;var a,h,g,c;c=n.match(/^(\d{2}|\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)(|\.\d+)Z$/);if(c){a=c[1];l=parseInt(a);if(a.length===2){if(50<=l&&l<100){l=1900+l;}else {if(0<=l&&l<50){l=2000+l;}}}j=parseInt(c[2])-1;m=parseInt(c[3]);e=parseInt(c[4]);f=parseInt(c[5]);i=parseInt(c[6]);b=0;h=c[7];if(h!==""){g=(h.substr(1)+"00").substr(0,3);b=parseInt(g);}return Date.UTC(l,j,m,e,f,i,b)}throw "unsupported zulu format: "+n}function zulutosec(a){var b=zulutomsec(a);return ~~(b/1000)}function uricmptohex(a){return a.replace(/%/g,"")}function hextouricmp(a){return a.replace(/(..)/g,"%$1")}function encodeURIComponentAll(a){var d=encodeURIComponent(a);var b="";for(var c=0;c<d.length;c++){if(d[c]=="%"){b=b+d.substr(c,3);c=c+2;}else {b=b+"%"+stohex(d[c]);}}return b}KJUR.lang.String.isInteger=function(a){if(a.match(/^[0-9]+$/)){return true}else {if(a.match(/^-[0-9]+$/)){return true}else {return false}}};KJUR.lang.String.isHex=function(a){if(a.length%2==0&&(a.match(/^[0-9a-f]+$/)||a.match(/^[0-9A-F]+$/))){return true}else {return false}};KJUR.lang.String.isBase64=function(a){a=a.replace(/\s+/g,"");if(a.match(/^[0-9A-Za-z+\/]+={0,3}$/)&&a.length%4==0){return true}else {return false}};KJUR.lang.String.isBase64URL=function(a){if(a.match(/[+/=]/)){return false}a=b64utob64(a);return KJUR.lang.String.isBase64(a)};KJUR.lang.String.isIntegerArray=function(a){a=a.replace(/\s+/g,"");if(a.match(/^\[[0-9,]+\]$/)){return true}else {return false}};if(typeof KJUR=="undefined"||!KJUR){KJUR={};}if(typeof KJUR.crypto=="undefined"||!KJUR.crypto){KJUR.crypto={};}KJUR.crypto.Util=new function(){this.DIGESTINFOHEAD={sha1:"3021300906052b0e03021a05000414",sha224:"302d300d06096086480165030402040500041c",sha256:"3031300d060960864801650304020105000420",sha384:"3041300d060960864801650304020205000430",sha512:"3051300d060960864801650304020305000440",md2:"3020300c06082a864886f70d020205000410",md5:"3020300c06082a864886f70d020505000410",ripemd160:"3021300906052b2403020105000414",};this.DEFAULTPROVIDER={md5:"cryptojs",sha1:"cryptojs",sha224:"cryptojs",sha256:"cryptojs",sha384:"cryptojs",sha512:"cryptojs",ripemd160:"cryptojs",hmacmd5:"cryptojs",hmacsha1:"cryptojs",hmacsha224:"cryptojs",hmacsha256:"cryptojs",hmacsha384:"cryptojs",hmacsha512:"cryptojs",hmacripemd160:"cryptojs",MD5withRSA:"cryptojs/jsrsa",SHA1withRSA:"cryptojs/jsrsa",SHA224withRSA:"cryptojs/jsrsa",SHA256withRSA:"cryptojs/jsrsa",SHA384withRSA:"cryptojs/jsrsa",SHA512withRSA:"cryptojs/jsrsa",RIPEMD160withRSA:"cryptojs/jsrsa",MD5withECDSA:"cryptojs/jsrsa",SHA1withECDSA:"cryptojs/jsrsa",SHA224withECDSA:"cryptojs/jsrsa",SHA256withECDSA:"cryptojs/jsrsa",SHA384withECDSA:"cryptojs/jsrsa",SHA512withECDSA:"cryptojs/jsrsa",RIPEMD160withECDSA:"cryptojs/jsrsa",SHA1withDSA:"cryptojs/jsrsa",SHA224withDSA:"cryptojs/jsrsa",SHA256withDSA:"cryptojs/jsrsa",MD5withRSAandMGF1:"cryptojs/jsrsa",SHA1withRSAandMGF1:"cryptojs/jsrsa",SHA224withRSAandMGF1:"cryptojs/jsrsa",SHA256withRSAandMGF1:"cryptojs/jsrsa",SHA384withRSAandMGF1:"cryptojs/jsrsa",SHA512withRSAandMGF1:"cryptojs/jsrsa",RIPEMD160withRSAandMGF1:"cryptojs/jsrsa",};this.CRYPTOJSMESSAGEDIGESTNAME={md5:CryptoJS.algo.MD5,sha1:CryptoJS.algo.SHA1,sha224:CryptoJS.algo.SHA224,sha256:CryptoJS.algo.SHA256,sha384:CryptoJS.algo.SHA384,sha512:CryptoJS.algo.SHA512,ripemd160:CryptoJS.algo.RIPEMD160};this.getDigestInfoHex=function(a,b){if(typeof this.DIGESTINFOHEAD[b]=="undefined"){throw "alg not supported in Util.DIGESTINFOHEAD: "+b}return this.DIGESTINFOHEAD[b]+a};this.getPaddedDigestInfoHex=function(h,a,j){var c=this.getDigestInfoHex(h,a);var d=j/4;if(c.length+22>d){throw "key is too short for SigAlg: keylen="+j+","+a}var b="0001";var k="00"+c;var g="";var l=d-b.length-k.length;for(var f=0;f<l;f+=2){g+="ff";}var e=b+g+k;return e};this.hashString=function(a,c){var b=new KJUR.crypto.MessageDigest({alg:c});return b.digestString(a)};this.hashHex=function(b,c){var a=new KJUR.crypto.MessageDigest({alg:c});return a.digestHex(b)};this.sha1=function(a){var b=new KJUR.crypto.MessageDigest({alg:"sha1",prov:"cryptojs"});return b.digestString(a)};this.sha256=function(a){var b=new KJUR.crypto.MessageDigest({alg:"sha256",prov:"cryptojs"});return b.digestString(a)};this.sha256Hex=function(a){var b=new KJUR.crypto.MessageDigest({alg:"sha256",prov:"cryptojs"});return b.digestHex(a)};this.sha512=function(a){var b=new KJUR.crypto.MessageDigest({alg:"sha512",prov:"cryptojs"});return b.digestString(a)};this.sha512Hex=function(a){var b=new KJUR.crypto.MessageDigest({alg:"sha512",prov:"cryptojs"});return b.digestHex(a)};};KJUR.crypto.Util.md5=function(a){var b=new KJUR.crypto.MessageDigest({alg:"md5",prov:"cryptojs"});return b.digestString(a)};KJUR.crypto.Util.ripemd160=function(a){var b=new KJUR.crypto.MessageDigest({alg:"ripemd160",prov:"cryptojs"});return b.digestString(a)};KJUR.crypto.Util.SECURERANDOMGEN=new SecureRandom();KJUR.crypto.Util.getRandomHexOfNbytes=function(b){var a=new Array(b);KJUR.crypto.Util.SECURERANDOMGEN.nextBytes(a);return BAtohex(a)};KJUR.crypto.Util.getRandomBigIntegerOfNbytes=function(a){return new BigInteger(KJUR.crypto.Util.getRandomHexOfNbytes(a),16)};KJUR.crypto.Util.getRandomHexOfNbits=function(d){var c=d%8;var a=(d-c)/8;var b=new Array(a+1);KJUR.crypto.Util.SECURERANDOMGEN.nextBytes(b);b[0]=(((255<<c)&255)^255)&b[0];return BAtohex(b)};KJUR.crypto.Util.getRandomBigIntegerOfNbits=function(a){return new BigInteger(KJUR.crypto.Util.getRandomHexOfNbits(a),16)};KJUR.crypto.Util.getRandomBigIntegerZeroToMax=function(b){var a=b.bitLength();while(1){var c=KJUR.crypto.Util.getRandomBigIntegerOfNbits(a);if(b.compareTo(c)!=-1){return c}}};KJUR.crypto.Util.getRandomBigIntegerMinToMax=function(e,b){var c=e.compareTo(b);if(c==1){throw "biMin is greater than biMax"}if(c==0){return e}var a=b.subtract(e);var d=KJUR.crypto.Util.getRandomBigIntegerZeroToMax(a);return d.add(e)};KJUR.crypto.MessageDigest=function(c){this.setAlgAndProvider=function(g,f){g=KJUR.crypto.MessageDigest.getCanonicalAlgName(g);if(g!==null&&f===undefined){f=KJUR.crypto.Util.DEFAULTPROVIDER[g];}if(":md5:sha1:sha224:sha256:sha384:sha512:ripemd160:".indexOf(g)!=-1&&f=="cryptojs"){try{this.md=KJUR.crypto.Util.CRYPTOJSMESSAGEDIGESTNAME[g].create();}catch(e){throw "setAlgAndProvider hash alg set fail alg="+g+"/"+e}this.updateString=function(h){this.md.update(h);};this.updateHex=function(h){var i=CryptoJS.enc.Hex.parse(h);this.md.update(i);};this.digest=function(){var h=this.md.finalize();return h.toString(CryptoJS.enc.Hex)};this.digestString=function(h){this.updateString(h);return this.digest()};this.digestHex=function(h){this.updateHex(h);return this.digest()};}if(":sha256:".indexOf(g)!=-1&&f=="sjcl"){try{this.md=new sjcl.hash.sha256();}catch(e){throw "setAlgAndProvider hash alg set fail alg="+g+"/"+e}this.updateString=function(h){this.md.update(h);};this.updateHex=function(i){var h=sjcl.codec.hex.toBits(i);this.md.update(h);};this.digest=function(){var h=this.md.finalize();return sjcl.codec.hex.fromBits(h)};this.digestString=function(h){this.updateString(h);return this.digest()};this.digestHex=function(h){this.updateHex(h);return this.digest()};}};this.updateString=function(e){throw "updateString(str) not supported for this alg/prov: "+this.algName+"/"+this.provName};this.updateHex=function(e){throw "updateHex(hex) not supported for this alg/prov: "+this.algName+"/"+this.provName};this.digest=function(){throw "digest() not supported for this alg/prov: "+this.algName+"/"+this.provName};this.digestString=function(e){throw "digestString(str) not supported for this alg/prov: "+this.algName+"/"+this.provName};this.digestHex=function(e){throw "digestHex(hex) not supported for this alg/prov: "+this.algName+"/"+this.provName};if(c!==undefined){if(c.alg!==undefined){this.algName=c.alg;if(c.prov===undefined){this.provName=KJUR.crypto.Util.DEFAULTPROVIDER[this.algName];}this.setAlgAndProvider(this.algName,this.provName);}}};KJUR.crypto.MessageDigest.getCanonicalAlgName=function(a){if(typeof a==="string"){a=a.toLowerCase();a=a.replace(/-/,"");}return a};KJUR.crypto.MessageDigest.getHashLength=function(c){var b=KJUR.crypto.MessageDigest;var a=b.getCanonicalAlgName(c);if(b.HASHLENGTH[a]===undefined){throw "not supported algorithm: "+c}return b.HASHLENGTH[a]};KJUR.crypto.MessageDigest.HASHLENGTH={md5:16,sha1:20,sha224:28,sha256:32,sha384:48,sha512:64,ripemd160:20};KJUR.crypto.Mac=function(d){this.setAlgAndProvider=function(k,i){k=k.toLowerCase();if(k==null){k="hmacsha1";}k=k.toLowerCase();if(k.substr(0,4)!="hmac"){throw "setAlgAndProvider unsupported HMAC alg: "+k}if(i===undefined){i=KJUR.crypto.Util.DEFAULTPROVIDER[k];}this.algProv=k+"/"+i;var g=k.substr(4);if(":md5:sha1:sha224:sha256:sha384:sha512:ripemd160:".indexOf(g)!=-1&&i=="cryptojs"){try{var j=KJUR.crypto.Util.CRYPTOJSMESSAGEDIGESTNAME[g];this.mac=CryptoJS.algo.HMAC.create(j,this.pass);}catch(h){throw "setAlgAndProvider hash alg set fail hashAlg="+g+"/"+h}this.updateString=function(l){this.mac.update(l);};this.updateHex=function(l){var m=CryptoJS.enc.Hex.parse(l);this.mac.update(m);};this.doFinal=function(){var l=this.mac.finalize();return l.toString(CryptoJS.enc.Hex)};this.doFinalString=function(l){this.updateString(l);return this.doFinal()};this.doFinalHex=function(l){this.updateHex(l);return this.doFinal()};}};this.updateString=function(g){throw "updateString(str) not supported for this alg/prov: "+this.algProv};this.updateHex=function(g){throw "updateHex(hex) not supported for this alg/prov: "+this.algProv};this.doFinal=function(){throw "digest() not supported for this alg/prov: "+this.algProv};this.doFinalString=function(g){throw "digestString(str) not supported for this alg/prov: "+this.algProv};this.doFinalHex=function(g){throw "digestHex(hex) not supported for this alg/prov: "+this.algProv};this.setPassword=function(h){if(typeof h=="string"){var g=h;if(h.length%2==1||!h.match(/^[0-9A-Fa-f]+$/)){g=rstrtohex(h);}this.pass=CryptoJS.enc.Hex.parse(g);return}if(typeof h!="object"){throw "KJUR.crypto.Mac unsupported password type: "+h}var g=null;if(h.hex!==undefined){if(h.hex.length%2!=0||!h.hex.match(/^[0-9A-Fa-f]+$/)){throw "Mac: wrong hex password: "+h.hex}g=h.hex;}if(h.utf8!==undefined){g=utf8tohex(h.utf8);}if(h.rstr!==undefined){g=rstrtohex(h.rstr);}if(h.b64!==undefined){g=b64tohex(h.b64);}if(h.b64u!==undefined){g=b64utohex(h.b64u);}if(g==null){throw "KJUR.crypto.Mac unsupported password type: "+h}this.pass=CryptoJS.enc.Hex.parse(g);};if(d!==undefined){if(d.pass!==undefined){this.setPassword(d.pass);}if(d.alg!==undefined){this.algName=d.alg;if(d.prov===undefined){this.provName=KJUR.crypto.Util.DEFAULTPROVIDER[this.algName];}this.setAlgAndProvider(this.algName,this.provName);}}};KJUR.crypto.Signature=function(o){var q=null;this._setAlgNames=function(){var s=this.algName.match(/^(.+)with(.+)$/);if(s){this.mdAlgName=s[1].toLowerCase();this.pubkeyAlgName=s[2].toLowerCase();}};this._zeroPaddingOfSignature=function(x,w){var v="";var t=w/4-x.length;for(var u=0;u<t;u++){v=v+"0";}return v+x};this.setAlgAndProvider=function(u,t){this._setAlgNames();if(t!="cryptojs/jsrsa"){throw "provider not supported: "+t}if(":md5:sha1:sha224:sha256:sha384:sha512:ripemd160:".indexOf(this.mdAlgName)!=-1){try{this.md=new KJUR.crypto.MessageDigest({alg:this.mdAlgName});}catch(s){throw "setAlgAndProvider hash alg set fail alg="+this.mdAlgName+"/"+s}this.init=function(w,x){var y=null;try{if(x===undefined){y=KEYUTIL.getKey(w);}else {y=KEYUTIL.getKey(w,x);}}catch(v){throw "init failed:"+v}if(y.isPrivate===true){this.prvKey=y;this.state="SIGN";}else {if(y.isPublic===true){this.pubKey=y;this.state="VERIFY";}else {throw "init failed.:"+y}}};this.updateString=function(v){this.md.updateString(v);};this.updateHex=function(v){this.md.updateHex(v);};this.sign=function(){this.sHashHex=this.md.digest();if(typeof this.ecprvhex!="undefined"&&typeof this.eccurvename!="undefined"){var v=new KJUR.crypto.ECDSA({curve:this.eccurvename});this.hSign=v.signHex(this.sHashHex,this.ecprvhex);}else {if(this.prvKey instanceof RSAKey&&this.pubkeyAlgName==="rsaandmgf1"){this.hSign=this.prvKey.signWithMessageHashPSS(this.sHashHex,this.mdAlgName,this.pssSaltLen);}else {if(this.prvKey instanceof RSAKey&&this.pubkeyAlgName==="rsa"){this.hSign=this.prvKey.signWithMessageHash(this.sHashHex,this.mdAlgName);}else {if(this.prvKey instanceof KJUR.crypto.ECDSA){this.hSign=this.prvKey.signWithMessageHash(this.sHashHex);}else {if(this.prvKey instanceof KJUR.crypto.DSA){this.hSign=this.prvKey.signWithMessageHash(this.sHashHex);}else {throw "Signature: unsupported private key alg: "+this.pubkeyAlgName}}}}}return this.hSign};this.signString=function(v){this.updateString(v);return this.sign()};this.signHex=function(v){this.updateHex(v);return this.sign()};this.verify=function(v){this.sHashHex=this.md.digest();if(typeof this.ecpubhex!="undefined"&&typeof this.eccurvename!="undefined"){var w=new KJUR.crypto.ECDSA({curve:this.eccurvename});return w.verifyHex(this.sHashHex,v,this.ecpubhex)}else {if(this.pubKey instanceof RSAKey&&this.pubkeyAlgName==="rsaandmgf1"){return this.pubKey.verifyWithMessageHashPSS(this.sHashHex,v,this.mdAlgName,this.pssSaltLen)}else {if(this.pubKey instanceof RSAKey&&this.pubkeyAlgName==="rsa"){return this.pubKey.verifyWithMessageHash(this.sHashHex,v)}else {if(KJUR.crypto.ECDSA!==undefined&&this.pubKey instanceof KJUR.crypto.ECDSA){return this.pubKey.verifyWithMessageHash(this.sHashHex,v)}else {if(KJUR.crypto.DSA!==undefined&&this.pubKey instanceof KJUR.crypto.DSA){return this.pubKey.verifyWithMessageHash(this.sHashHex,v)}else {throw "Signature: unsupported public key alg: "+this.pubkeyAlgName}}}}}};}};this.init=function(s,t){throw "init(key, pass) not supported for this alg:prov="+this.algProvName};this.updateString=function(s){throw "updateString(str) not supported for this alg:prov="+this.algProvName};this.updateHex=function(s){throw "updateHex(hex) not supported for this alg:prov="+this.algProvName};this.sign=function(){throw "sign() not supported for this alg:prov="+this.algProvName};this.signString=function(s){throw "digestString(str) not supported for this alg:prov="+this.algProvName};this.signHex=function(s){throw "digestHex(hex) not supported for this alg:prov="+this.algProvName};this.verify=function(s){throw "verify(hSigVal) not supported for this alg:prov="+this.algProvName};this.initParams=o;if(o!==undefined){if(o.alg!==undefined){this.algName=o.alg;if(o.prov===undefined){this.provName=KJUR.crypto.Util.DEFAULTPROVIDER[this.algName];}else {this.provName=o.prov;}this.algProvName=this.algName+":"+this.provName;this.setAlgAndProvider(this.algName,this.provName);this._setAlgNames();}if(o.psssaltlen!==undefined){this.pssSaltLen=o.psssaltlen;}if(o.prvkeypem!==undefined){if(o.prvkeypas!==undefined){throw "both prvkeypem and prvkeypas parameters not supported"}else {try{var q=KEYUTIL.getKey(o.prvkeypem);this.init(q);}catch(m){throw "fatal error to load pem private key: "+m}}}}};KJUR.crypto.Cipher=function(a){};KJUR.crypto.Cipher.encrypt=function(e,f,d){if(f instanceof RSAKey&&f.isPublic){var c=KJUR.crypto.Cipher.getAlgByKeyAndName(f,d);if(c==="RSA"){return f.encrypt(e)}if(c==="RSAOAEP"){return f.encryptOAEP(e,"sha1")}var b=c.match(/^RSAOAEP(\d+)$/);if(b!==null){return f.encryptOAEP(e,"sha"+b[1])}throw "Cipher.encrypt: unsupported algorithm for RSAKey: "+d}else {throw "Cipher.encrypt: unsupported key or algorithm"}};KJUR.crypto.Cipher.decrypt=function(e,f,d){if(f instanceof RSAKey&&f.isPrivate){var c=KJUR.crypto.Cipher.getAlgByKeyAndName(f,d);if(c==="RSA"){return f.decrypt(e)}if(c==="RSAOAEP"){return f.decryptOAEP(e,"sha1")}var b=c.match(/^RSAOAEP(\d+)$/);if(b!==null){return f.decryptOAEP(e,"sha"+b[1])}throw "Cipher.decrypt: unsupported algorithm for RSAKey: "+d}else {throw "Cipher.decrypt: unsupported key or algorithm"}};KJUR.crypto.Cipher.getAlgByKeyAndName=function(b,a){if(b instanceof RSAKey){if(":RSA:RSAOAEP:RSAOAEP224:RSAOAEP256:RSAOAEP384:RSAOAEP512:".indexOf(a)!=-1){return a}if(a===null||a===undefined){return "RSA"}throw "getAlgByKeyAndName: not supported algorithm name for RSAKey: "+a}throw "getAlgByKeyAndName: not supported algorithm name: "+a};KJUR.crypto.OID=new function(){this.oidhex2name={"2a864886f70d010101":"rsaEncryption","2a8648ce3d0201":"ecPublicKey","2a8648ce380401":"dsa","2a8648ce3d030107":"secp256r1","2b8104001f":"secp192k1","2b81040021":"secp224r1","2b8104000a":"secp256k1","2b81040023":"secp521r1","2b81040022":"secp384r1","2a8648ce380403":"SHA1withDSA","608648016503040301":"SHA224withDSA","608648016503040302":"SHA256withDSA",};};
    if(typeof KJUR=="undefined"||!KJUR){KJUR={};}if(typeof KJUR.jws=="undefined"||!KJUR.jws){KJUR.jws={};}KJUR.jws.JWS=function(){var b=KJUR,a=b.jws.JWS,c=a.isSafeJSONString;this.parseJWS=function(g,j){if((this.parsedJWS!==undefined)&&(j||(this.parsedJWS.sigvalH!==undefined))){return}var i=g.match(/^([^.]+)\.([^.]+)\.([^.]+)$/);if(i==null){throw "JWS signature is not a form of 'Head.Payload.SigValue'."}var k=i[1];var e=i[2];var l=i[3];var n=k+"."+e;this.parsedJWS={};this.parsedJWS.headB64U=k;this.parsedJWS.payloadB64U=e;this.parsedJWS.sigvalB64U=l;this.parsedJWS.si=n;if(!j){var h=b64utohex(l);var f=parseBigInt(h,16);this.parsedJWS.sigvalH=h;this.parsedJWS.sigvalBI=f;}var d=b64utoutf8(k);var m=b64utoutf8(e);this.parsedJWS.headS=d;this.parsedJWS.payloadS=m;if(!c(d,this.parsedJWS,"headP")){throw "malformed JSON string for JWS Head: "+d}};};KJUR.jws.JWS.sign=function(i,v,y,z,a){var w=KJUR,m=w.jws,q=m.JWS,g=q.readSafeJSONString,p=q.isSafeJSONString,d=w.crypto;d.ECDSA;var o=d.Mac,c=d.Signature,t=JSON;var s,j,n;if(typeof v!="string"&&typeof v!="object"){throw "spHeader must be JSON string or object: "+v}if(typeof v=="object"){j=v;s=t.stringify(j);}if(typeof v=="string"){s=v;if(!p(s)){throw "JWS Head is not safe JSON string: "+s}j=g(s);}n=y;if(typeof y=="object"){n=t.stringify(y);}if((i==""||i==null)&&j.alg!==undefined){i=j.alg;}if((i!=""&&i!=null)&&j.alg===undefined){j.alg=i;s=t.stringify(j);}if(i!==j.alg){throw "alg and sHeader.alg doesn't match: "+i+"!="+j.alg}var r=null;if(q.jwsalg2sigalg[i]===undefined){throw "unsupported alg name: "+i}else {r=q.jwsalg2sigalg[i];}var e=utf8tob64u(s);var l=utf8tob64u(n);var b=e+"."+l;var x="";if(r.substr(0,4)=="Hmac"){if(z===undefined){throw "mac key shall be specified for HS* alg"}var h=new o({alg:r,prov:"cryptojs",pass:z});h.updateString(b);x=h.doFinal();}else {if(r.indexOf("withECDSA")!=-1){var f=new c({alg:r});f.init(z,a);f.updateString(b);hASN1Sig=f.sign();x=KJUR.crypto.ECDSA.asn1SigToConcatSig(hASN1Sig);}else {if(r!="none"){var f=new c({alg:r});f.init(z,a);f.updateString(b);x=f.sign();}}}var u=hextob64u(x);return b+"."+u};KJUR.jws.JWS.verify=function(w,B,n){var x=KJUR,q=x.jws,t=q.JWS,i=t.readSafeJSONString,e=x.crypto,p=e.ECDSA,s=e.Mac,d=e.Signature,m;/*if(typeof RSAKey!==undefined){m=RSAKey}*/var y=w.split(".");if(y.length!==3){return false}var f=y[0];var r=y[1];var c=f+"."+r;var A=b64utohex(y[2]);var l=i(b64utoutf8(y[0]));var k=null;var z=null;if(l.alg===undefined){throw "algorithm not specified in header"}else {k=l.alg;z=k.substr(0,2);}if(n!=null&&Object.prototype.toString.call(n)==="[object Array]"&&n.length>0){var b=":"+n.join(":")+":";if(b.indexOf(":"+k+":")==-1){throw "algorithm '"+k+"' not accepted in the list"}}if(k!="none"&&B===null){throw "key shall be specified to verify."}if(typeof B=="string"&&B.indexOf("-----BEGIN ")!=-1){B=KEYUTIL.getKey(B);}if(z=="RS"||z=="PS"){if(!(B instanceof m)){throw "key shall be a RSAKey obj for RS* and PS* algs"}}if(z=="ES"){if(!(B instanceof p)){throw "key shall be a ECDSA obj for ES* algs"}}var u=null;if(t.jwsalg2sigalg[l.alg]===undefined){throw "unsupported alg name: "+k}else {u=t.jwsalg2sigalg[k];}if(u=="none"){throw "not supported"}else {if(u.substr(0,4)=="Hmac"){var o=null;if(B===undefined){throw "hexadecimal key shall be specified for HMAC"}var j=new s({alg:u,pass:B});j.updateString(c);o=j.doFinal();return A==o}else {if(u.indexOf("withECDSA")!=-1){var h=null;try{h=p.concatSigToASN1Sig(A);}catch(v){return false}var g=new d({alg:u});g.init(B);g.updateString(c);return g.verify(h)}else {var g=new d({alg:u});g.init(B);g.updateString(c);return g.verify(A)}}}};KJUR.jws.JWS.parse=function(g){var c=g.split(".");var b={};var f,e,d;if(c.length!=2&&c.length!=3){throw "malformed sJWS: wrong number of '.' splitted elements"}f=c[0];e=c[1];if(c.length==3){d=c[2];}b.headerObj=KJUR.jws.JWS.readSafeJSONString(b64utoutf8(f));b.payloadObj=KJUR.jws.JWS.readSafeJSONString(b64utoutf8(e));b.headerPP=JSON.stringify(b.headerObj,null,"  ");if(b.payloadObj==null){b.payloadPP=b64utoutf8(e);}else {b.payloadPP=JSON.stringify(b.payloadObj,null,"  ");}if(d!==undefined){b.sigHex=b64utohex(d);}return b};KJUR.jws.JWS.verifyJWT=function(e,l,r){var d=KJUR,j=d.jws,o=j.JWS,n=o.readSafeJSONString,p=o.inArray,f=o.includedArray;var k=e.split(".");var c=k[0];var i=k[1];b64utohex(k[2]);var h=n(b64utoutf8(c));var g=n(b64utoutf8(i));if(h.alg===undefined){return false}if(r.alg===undefined){throw "acceptField.alg shall be specified"}if(!p(h.alg,r.alg)){return false}if(g.iss!==undefined&&typeof r.iss==="object"){if(!p(g.iss,r.iss)){return false}}if(g.sub!==undefined&&typeof r.sub==="object"){if(!p(g.sub,r.sub)){return false}}if(g.aud!==undefined&&typeof r.aud==="object"){if(typeof g.aud=="string"){if(!p(g.aud,r.aud)){return false}}else {if(typeof g.aud=="object"){if(!f(g.aud,r.aud)){return false}}}}var b=j.IntDate.getNow();if(r.verifyAt!==undefined&&typeof r.verifyAt==="number"){b=r.verifyAt;}if(r.gracePeriod===undefined||typeof r.gracePeriod!=="number"){r.gracePeriod=0;}if(g.exp!==undefined&&typeof g.exp=="number"){if(g.exp+r.gracePeriod<b){return false}}if(g.nbf!==undefined&&typeof g.nbf=="number"){if(b<g.nbf-r.gracePeriod){return false}}if(g.iat!==undefined&&typeof g.iat=="number"){if(b<g.iat-r.gracePeriod){return false}}if(g.jti!==undefined&&r.jti!==undefined){if(g.jti!==r.jti){return false}}if(!o.verify(e,l,r.alg)){return false}return true};KJUR.jws.JWS.includedArray=function(b,a){var c=KJUR.jws.JWS.inArray;if(b===null){return false}if(typeof b!=="object"){return false}if(typeof b.length!=="number"){return false}for(var d=0;d<b.length;d++){if(!c(b[d],a)){return false}}return true};KJUR.jws.JWS.inArray=function(d,b){if(b===null){return false}if(typeof b!=="object"){return false}if(typeof b.length!=="number"){return false}for(var c=0;c<b.length;c++){if(b[c]==d){return true}}return false};KJUR.jws.JWS.jwsalg2sigalg={HS256:"HmacSHA256",HS384:"HmacSHA384",HS512:"HmacSHA512",RS256:"SHA256withRSA",RS384:"SHA384withRSA",RS512:"SHA512withRSA",ES256:"SHA256withECDSA",ES384:"SHA384withECDSA",PS256:"SHA256withRSAandMGF1",PS384:"SHA384withRSAandMGF1",PS512:"SHA512withRSAandMGF1",none:"none",};KJUR.jws.JWS.isSafeJSONString=function(c,b,d){var e=null;try{e=jsonParse(c);if(typeof e!="object"){return 0}if(e.constructor===Array){return 0}if(b){b[d]=e;}return 1}catch(a){return 0}};KJUR.jws.JWS.readSafeJSONString=function(b){var c=null;try{c=jsonParse(b);if(typeof c!="object"){return null}if(c.constructor===Array){return null}return c}catch(a){return null}};KJUR.jws.JWS.getEncodedSignatureValueFromJWS=function(b){var a=b.match(/^[^.]+\.[^.]+\.([^.]+)$/);if(a==null){throw "JWS signature is not a form of 'Head.Payload.SigValue'."}return a[1]};KJUR.jws.JWS.getJWKthumbprint=function(d){if(d.kty!=="RSA"&&d.kty!=="EC"&&d.kty!=="oct"){throw "unsupported algorithm for JWK Thumprint"}var a="{";if(d.kty==="RSA"){if(typeof d.n!="string"||typeof d.e!="string"){throw "wrong n and e value for RSA key"}a+='"e":"'+d.e+'",';a+='"kty":"'+d.kty+'",';a+='"n":"'+d.n+'"}';}else {if(d.kty==="EC"){if(typeof d.crv!="string"||typeof d.x!="string"||typeof d.y!="string"){throw "wrong crv, x and y value for EC key"}a+='"crv":"'+d.crv+'",';a+='"kty":"'+d.kty+'",';a+='"x":"'+d.x+'",';a+='"y":"'+d.y+'"}';}else {if(d.kty==="oct"){if(typeof d.k!="string"){throw "wrong k value for oct(symmetric) key"}a+='"kty":"'+d.kty+'",';a+='"k":"'+d.k+'"}';}}}var b=rstrtohex(a);var c=KJUR.crypto.Util.hashHex(b,"sha256");var e=hextob64u(c);return e};KJUR.jws.IntDate={};KJUR.jws.IntDate.get=function(c){var b=KJUR.jws.IntDate,d=b.getNow,a=b.getZulu;if(c=="now"){return d()}else {if(c=="now + 1hour"){return d()+60*60}else {if(c=="now + 1day"){return d()+60*60*24}else {if(c=="now + 1month"){return d()+60*60*24*30}else {if(c=="now + 1year"){return d()+60*60*24*365}else {if(c.match(/Z$/)){return a(c)}else {if(c.match(/^[0-9]+$/)){return parseInt(c)}}}}}}}throw "unsupported format: "+c};KJUR.jws.IntDate.getZulu=function(a){return zulutosec(a)};KJUR.jws.IntDate.getNow=function(){var a=~~(new Date()/1000);return a};KJUR.jws.IntDate.intDate2UTCString=function(a){var b=new Date(a*1000);return b.toUTCString()};KJUR.jws.IntDate.intDate2Zulu=function(e){var i=new Date(e*1000),h=("0000"+i.getUTCFullYear()).slice(-4),g=("00"+(i.getUTCMonth()+1)).slice(-2),b=("00"+i.getUTCDate()).slice(-2),a=("00"+i.getUTCHours()).slice(-2),c=("00"+i.getUTCMinutes()).slice(-2),f=("00"+i.getUTCSeconds()).slice(-2);return h+g+b+a+c+f+"Z"};

    function sha256(input) {
        return KJUR.crypto.Util.sha256(input);
    }
    function isValidEmail(email) {
        // tslint:disable-next-line:max-line-length
        return (/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i).test(email);
    }
    function uniqueId(length, startWith) {
        if (length === void 0) { length = 12; }
        if (startWith === void 0) { startWith = '-'; }
        var maxLoop = length - 8;
        var ASCII_CHARS = startWith + '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz';
        var lastPushTime = 0;
        var lastRandChars = [];
        var now = new Date().getTime();
        var duplicateTime = (now === lastPushTime);
        lastPushTime = now;
        var timeStampChars = new Array(8);
        var i;
        for (i = 7; i >= 0; i--) {
            timeStampChars[i] = ASCII_CHARS.charAt(now % 64);
            now = Math.floor(now / 64);
        }
        var uid = timeStampChars.join('');
        if (!duplicateTime) {
            for (i = 0; i < maxLoop; i++) {
                lastRandChars[i] = Math.floor(Math.random() * 64);
            }
        }
        else {
            for (i = maxLoop - 1; i >= 0 && lastRandChars[i] === 63; i--) {
                lastRandChars[i] = 0;
            }
            lastRandChars[i]++;
        }
        for (i = 0; i < maxLoop; i++) {
            uid += ASCII_CHARS.charAt(lastRandChars[i]);
        }
        return uid;
    }

    var __assign$1 = function () {
        __assign$1 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$1.apply(this, arguments);
    };
    var User = /** @class */ (function () {
        function User(userData, Database, Token) {
            this.userData = userData;
            this.Database = Database;
            this.Token = Token;
        }
        User.prototype.getData = function () {
            return this.userData;
        };
        User.prototype.getInfo = function () {
            var _a = this.userData, uid = _a.uid, providerId = _a.providerId, _b = _a.email, email = _b === void 0 ? '' : _b, _c = _a.emailVerified, emailVerified = _c === void 0 ? false : _c, type = _a.type, _d = _a.createdAt, createdAt = _d === void 0 ? '' : _d, _e = _a.lastLogin, lastLogin = _e === void 0 ? '' : _e, _f = _a.username, username = _f === void 0 ? '' : _f, _g = _a.phoneNumber, phoneNumber = _g === void 0 ? '' : _g, _h = _a.displayName, displayName = _h === void 0 ? '' : _h, _j = _a.photoURL, photoURL = _j === void 0 ? '' : _j, _k = _a.bio, bio = _k === void 0 ? '' : _k, _l = _a.url, url = _l === void 0 ? '' : _l, _m = _a.addresses, addresses = _m === void 0 ? '' : _m, _o = _a.additionalData, additionalData = _o === void 0 ? null : _o, _p = _a.claims, claims = _p === void 0 ? null : _p, _q = _a.settings, settings = _q === void 0 ? null : _q, _r = _a.isNewUser, isNewUser = _r === void 0 ? false : _r;
            return {
                uid: uid,
                providerId: providerId,
                email: email,
                emailVerified: emailVerified,
                type: type,
                createdAt: createdAt,
                lastLogin: lastLogin,
                username: username,
                phoneNumber: phoneNumber,
                displayName: displayName,
                photoURL: photoURL,
                bio: bio,
                url: url,
                addresses: addresses,
                additionalData: additionalData,
                claims: claims,
                settings: settings,
                isAnonymous: !email && providerId === 'anonymous' ? true : false,
                isNewUser: isNewUser
            };
        };
        User.prototype.getIdToken = function () {
            return this.Token.signIdToken(this.userData);
        };
        User.prototype.comparePassword = function (password) {
            var _a = this.userData, _b = _a.uid, uid = _b === void 0 ? '' : _b, currentPasswordSecure = _a.password;
            var passwordSecure = sha256(uid + password);
            return passwordSecure === currentPasswordSecure;
        };
        User.prototype.getProvider = function () {
            var providerId = this.userData.providerId;
            return { providerId: providerId };
        };
        User.prototype.getProfile = function () {
            var _a = this.userData, uid = _a.uid, _b = _a.email, email = _b === void 0 ? '' : _b, type = _a.type, _c = _a.createdAt, createdAt = _c === void 0 ? '' : _c, _d = _a.phoneNumber, phoneNumber = _d === void 0 ? '' : _d, _e = _a.displayName, displayName = _e === void 0 ? '' : _e, _f = _a.photoURL, photoURL = _f === void 0 ? '' : _f, _g = _a.bio, bio = _g === void 0 ? '' : _g, _h = _a.url, url = _h === void 0 ? '' : _h, _j = _a.addresses, addresses = _j === void 0 ? '' : _j, _k = _a.additionalData, additionalData = _k === void 0 ? null : _k, _l = _a.claims, claims = _l === void 0 ? null : _l;
            var profile = {
                uid: uid,
                email: email,
                type: type,
                createdAt: createdAt,
                phoneNumber: phoneNumber,
                displayName: displayName,
                photoURL: photoURL,
                bio: bio,
                url: url,
                addresses: addresses,
                additionalData: additionalData,
                claims: claims
            };
            // clear empty field
            for (var _i = 0, _m = Object.keys(profile); _i < _m.length; _i++) {
                var key = _m[_i];
                if (!profile[key]) {
                    delete profile[key];
                }
            }
            return profile;
        };
        User.prototype.getPublicProfile = function () {
            var profile = this.getProfile();
            var _a = this.userData.settings, settings = _a === void 0 ? {} : _a;
            // remove private profile
            if (!settings.$email) {
                delete profile.email;
            }
            if (!settings.$phoneNumber) {
                delete profile.phoneNumber;
            }
            if (!settings.$addresses) {
                delete profile.addresses;
            }
            if (!settings.$type) {
                delete profile.type;
            }
            // remove private addional data
            var additionalData = profile.additionalData;
            if (!!additionalData && additionalData instanceof Object) {
                for (var _i = 0, _b = Object.keys(additionalData); _i < _b.length; _i++) {
                    var key = _b[_i];
                    if (!settings['$' + key]) {
                        delete additionalData[key];
                    }
                }
                // set it back
                profile.additionalData = additionalData;
            }
            // clear empty field
            for (var _c = 0, _d = Object.keys(profile); _c < _d.length; _c++) {
                var key = _d[_c];
                if (!profile[key]) {
                    delete profile[key];
                }
            }
            return profile;
        };
        User.prototype.updateProfile = function (data) {
            var allowedFields = ['displayName', 'photoURL', 'bio', 'url', 'addresses'];
            var profile = {};
            for (var i = 0; i < allowedFields.length; i++) {
                var field = allowedFields[i];
                if (!!data[field]) {
                    profile[field] = data[field];
                }
            }
            // apply
            this.userData = __assign$1({}, this.userData, profile);
            return this;
        };
        User.prototype.setAdditionalData = function (data) {
            this.userData.additionalData = __assign$1({}, this.userData.additionalData, data);
            return this;
        };
        User.prototype.setSettings = function (data) {
            this.userData.settings = __assign$1({}, this.userData.settings, data);
            return this;
        };
        User.prototype.setProfilePublicly = function (props) {
            var _a = this.userData.settings, settings = _a === void 0 ? {} : _a;
            // turn string to string[]
            if (typeof props === 'string') {
                props = [props];
            }
            // set props
            for (var i = 0; i < props.length; i++) {
                settings['$' + props[i]] = true;
            }
            // set it back
            this.userData.settings = settings;
            return this;
        };
        User.prototype.setProfilePrivately = function (props) {
            var settings = this.userData.settings;
            if (!!settings && settings instanceof Object) {
                // turn string to string[]
                if (typeof props === 'string') {
                    props = [props];
                }
                // set props
                for (var i = 0; i < props.length; i++) {
                    delete settings['$' + props[i]];
                }
                // set it back
                this.userData.settings = settings;
            }
            return this;
        };
        User.prototype.updateClaims = function (claims) {
            this.userData.claims = __assign$1({}, this.userData.claims, claims);
            return this;
        };
        User.prototype.setlastLogin = function () {
            this.userData.lastLogin = new Date().toISOString();
            return this;
        };
        User.prototype.setEmail = function (email) {
            this.userData.email = email;
            return this;
        };
        User.prototype.confirmEmail = function () {
            this.userData.emailVerified = true;
            return this;
        };
        User.prototype.setPassword = function (password) {
            // TODO: implement bcrypt
            var _a = this.userData.uid, uid = _a === void 0 ? '' : _a;
            this.userData.password = sha256(uid + password);
            return this;
        };
        User.prototype.setUsername = function (username) {
            this.userData.username = username;
            return this;
        };
        User.prototype.setPhoneNumber = function (phoneNumber) {
            this.userData.phoneNumber = phoneNumber;
            return this;
        };
        User.prototype.setOob = function (mode) {
            if (mode === void 0) { mode = 'none'; }
            var uid = this.userData.uid;
            // valid modes
            if (mode !== 'resetPassword' && mode !== 'verifyEmail') {
                mode = 'none';
            }
            this.userData.oobCode = sha256(uid + Utilities.getUuid());
            this.userData.oobMode = mode;
            this.userData.oobTimestamp = (new Date()).getTime();
            return this;
        };
        User.prototype.setRefreshToken = function () {
            this.userData.refreshToken = uniqueId(64, 'A');
            this.userData.tokenTimestamp = (new Date()).getTime();
            return this;
        };
        User.prototype["delete"] = function () {
            var uid = this.userData.uid;
            this.Database.deleteUser(uid);
            return this;
        };
        User.prototype.save = function () {
            var uid = this.userData.uid;
            if (!!uid) {
                this.Database.updateUser(uid, this.userData);
            }
            else {
                this.Database.addUser(uid, this.userData);
            }
            return this;
        };
        return User;
    }());

    var OobService = /** @class */ (function () {
        function OobService(options) {
            var authUrl = options.authUrl, _a = options.emailPrefix, emailPrefix = _a === void 0 ? 'Sheetbase' : _a, emailSubject = options.emailSubject, emailBody = options.emailBody;
            this.authUrl = authUrl;
            this.emailPrefix = emailPrefix;
            this.emailSubject = emailSubject;
            this.emailBody = emailBody;
        }
        OobService.prototype.sendPasswordResetEmail = function (userData) {
            var displayName = userData.displayName, oobCode = userData.oobCode, oobMode = userData.oobMode;
            var url = this.buildAuthUrl(oobMode, oobCode);
            this.sendEmail(oobMode, url, userData, 'Reset your password', "<p>Hello " + (displayName || 'User') + "!</p>\n            <p>Here is your password reset link: <a href=\"" + url + "\">" + url + "</a>.</p>\n            <p>If you did not request for password reset, please ignore this email.</p>\n            <p>Thank you!</p>");
        };
        OobService.prototype.sendEmailVerificationEmail = function (userData) {
            var displayName = userData.displayName, oobCode = userData.oobCode, oobMode = userData.oobMode;
            var url = this.buildAuthUrl(oobMode, oobCode);
            this.sendEmail(oobMode, url, userData, 'Confirm your email', "<p>Hello " + (displayName || 'User') + "!</p>\n            <p>Click to confirm your email: <a href=\"" + url + "\">" + url + "</a>.</p>\n            <p>If you did not request for the action, please ignore this email.</p>\n            <p>Thank you!</p>");
        };
        OobService.prototype.buildAuthUrl = function (mode, code) {
            var authUrl = this.authUrl;
            if (!!authUrl && authUrl instanceof Function) {
                return authUrl(mode, code);
            }
            else {
                authUrl = !authUrl ? (ScriptApp.getService().getUrl() + '?e=auth/action&') : authUrl + '?';
                authUrl += "mode=" + mode + "&oobCode=" + code;
                return authUrl;
            }
        };
        OobService.prototype.buildEmailSubject = function (mode, defaultSubject) {
            if (!!this.emailSubject) {
                return this.emailSubject(mode);
            }
            return defaultSubject;
        };
        OobService.prototype.buildEmailBody = function (mode, url, userData, defaultBody) {
            if (!!this.emailBody) {
                return this.emailBody(mode, url, userData);
            }
            return defaultBody;
        };
        OobService.prototype.sendEmail = function (mode, url, userData, defaultSubject, defaultBody) {
            // build data
            var subject = '(' + this.emailPrefix + ') ' + this.buildEmailSubject(mode, defaultSubject);
            var htmlBody = this.buildEmailBody(mode, url, userData, defaultBody);
            var body = htmlBody.replace(/<[^>]*>?/g, '');
            var options = {
                name: this.emailPrefix,
                htmlBody: htmlBody
            };
            // send email
            var email = userData.email;
            GmailApp.sendEmail(email, subject, body, options);
            // retrieve thread
            Utilities.sleep(2000);
            var sentThreads = GmailApp.search('from:me to:' + email);
            var thread = sentThreads[0];
            // get label
            var labelName = this.emailPrefix + ':Oob';
            var label = GmailApp.getUserLabelByName(labelName);
            if (!label) {
                label = GmailApp.createLabel(labelName);
            }
            // set label
            thread.addLabel(label);
        };
        return OobService;
    }());

    var __assign$1$1 = function () {
        __assign$1$1 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$1$1.apply(this, arguments);
    };
    var TokenService = /** @class */ (function () {
        function TokenService(options) {
            this.encryptionSecret = options.encryptionSecret;
        }
        TokenService.prototype.sign = function (payload) {
            return KJUR.jws.JWS.sign('HS256', JSON.stringify({ alg: 'HS256', typ: 'JWT' }), JSON.stringify(__assign$1$1({}, payload, { iss: 'https://sheetbaseapp.com', aud: 'https://sheetbaseapp.com', iat: KJUR.jws.IntDate.get('now'), exp: KJUR.jws.IntDate.get('now + 1hour') })), { utf8: this.encryptionSecret });
        };
        TokenService.prototype.signIdToken = function (userData) {
            var uid = userData.uid, email = userData.email, _a = userData.claims, claims = _a === void 0 ? {} : _a;
            return this.sign(__assign$1$1({}, claims, { uid: uid, sub: email, tty: 'ID' }));
        };
        TokenService.prototype.decode = function (token, ands) {
            // check validation
            var valid = !!KJUR.jws.JWS.verifyJWT(token, { utf8: this.encryptionSecret }, {
                alg: ['HS256'],
                iss: ['https://sheetbaseapp.com'],
                aud: ['https://sheetbaseapp.com']
            });
            // extract the payload
            var payload;
            if (valid) {
                var payloadObj = KJUR.jws.JWS.parse(token).payloadObj;
                payload = payloadObj;
                // check ands
                if (!!ands) {
                    for (var _i = 0, _a = Object.keys(ands); _i < _a.length; _i++) {
                        var key = _a[_i];
                        if (!payload[key] || payload[key] !== ands[key]) {
                            valid = false;
                        }
                    }
                }
            }
            return valid ? payload : null;
        };
        TokenService.prototype.decodeIdToken = function (token) {
            return this.decode(token, { tty: 'ID' });
        };
        TokenService.prototype.decodeCustomToken = function (token) {
            return this.decode(token, { tty: 'CUSTOM' });
        };
        return TokenService;
    }());

    var OauthService = /** @class */ (function () {
        function OauthService() {
        }
        OauthService.prototype.getUserInfo = function (providerId, accessToken) {
            var url;
            // prepare url
            if (providerId === 'google.com') {
                url = 'https://www.googleapis.com/oauth2/v2/userinfo?access_token=' + accessToken;
            }
            else if (providerId === 'facebook.com') {
                url = 'https://graph.facebook.com/me?fields=id,email,name,picture' +
                    '&access_token=' + accessToken;
            }
            // fetch result
            var response = UrlFetchApp.fetch(url);
            // return result
            return JSON.parse(response.getContentText('UTF-8'));
        };
        OauthService.prototype.processUserInfo = function (providerId, data) {
            var profile = {};
            // extract data
            if (providerId === 'google.com') {
                var _a = data, name = _a.name, link = _a.link, picture = _a.picture;
                profile.displayName = name;
                profile.url = link;
                profile.photoURL = picture;
            }
            else if (providerId === 'facebook.com') {
                var _b = data, name = _b.name, picture = _b.picture;
                profile.displayName = name;
                profile.photoURL = (!!picture && !!picture.data) ? picture.data.url : '';
            }
            // return result
            return profile;
        };
        return OauthService;
    }());

    var __assign$2 = function () {
        __assign$2 = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign$2.apply(this, arguments);
    };
    var AccountService = /** @class */ (function () {
        function AccountService(options) {
            this.Database = options.databaseDriver;
            this.Token = new TokenService(options);
            this.Oauth = new OauthService();
        }
        AccountService.prototype.user = function (userData) {
            return new User(userData, this.Database, this.Token);
        };
        AccountService.prototype.getUser = function (finder) {
            var userData = this.Database.getUser(finder);
            return !!userData ? this.user(userData) : null;
        };
        AccountService.prototype.isUser = function (finder) {
            return !!this.getUser(finder);
        };
        AccountService.prototype.getUserByEmailAndPassword = function (email, password) {
            var user = this.getUser({ email: email });
            if (!user) {
                var newUser = {
                    uid: uniqueId(28, '1'),
                    providerId: 'password',
                    createdAt: new Date().toISOString(),
                    isNewUser: true
                };
                return this.user(newUser)
                    .setEmail(email)
                    .setPassword(password)
                    .setRefreshToken();
            }
            else if (!!user && user.comparePassword(password)) {
                return user;
            }
            else {
                return null;
            }
        };
        AccountService.prototype.getUserByCustomToken = function (customToken) {
            var payload = this.Token.decodeIdToken(customToken);
            if (!!payload) {
                var uid = payload.uid, claims = payload.developerClaims;
                var user = this.getUser(uid);
                if (!user) {
                    var newUser = {
                        uid: uid,
                        providerId: 'custom',
                        createdAt: new Date().toISOString(),
                        isNewUser: true
                    };
                    if (!!claims) {
                        newUser.claims = claims;
                    }
                    return this.user(newUser)
                        .setRefreshToken();
                }
                else {
                    return user;
                }
            }
            else {
                return null;
            }
        };
        AccountService.prototype.getUserAnonymously = function () {
            var newUser = {
                uid: uniqueId(28, '1'),
                providerId: 'anonymous',
                createdAt: new Date().toISOString(),
                isAnonymous: true,
                isNewUser: true
            };
            return this.user(newUser)
                .setRefreshToken();
        };
        AccountService.prototype.getUserByIdToken = function (idToken) {
            var payload = this.Token.decodeIdToken(idToken);
            if (!!payload) {
                var uid = payload.uid;
                var user = this.getUser(uid);
                if (!!user) {
                    return user;
                }
                else {
                    return null;
                }
            }
            else {
                return null;
            }
        };
        AccountService.prototype.getUserByOobCode = function (oobCode) {
            var user = this.getUser({ oobCode: oobCode });
            if (!!user) {
                var oobTimestamp = user.getData().oobTimestamp;
                var beenMinutes = Math.round(((new Date()).getTime() - oobTimestamp) / 60000);
                if (!!oobTimestamp && beenMinutes < 60) {
                    return user;
                }
                else {
                    return null;
                }
            }
            else {
                return null;
            }
        };
        AccountService.prototype.getUserByRefreshToken = function (refreshToken) {
            return this.getUser({ refreshToken: refreshToken });
        };
        AccountService.prototype.getUserByOauthProvider = function (providerId, accessToken) {
            var userInfo = this.Oauth.getUserInfo(providerId, accessToken);
            if (!!userInfo) {
                var id = userInfo.id, email = userInfo.email;
                if (!!email) { // google, facebook
                    var user = this.getUser({ email: email });
                    if (!user) {
                        // extract profile from userinfo
                        var userProfile = this.Oauth.processUserInfo(providerId, userInfo);
                        // new user
                        var newUser = __assign$2({}, userProfile, { uid: uniqueId(28, '1'), providerId: providerId, createdAt: new Date().toISOString(), emailVerified: true, isNewUser: true, additionalData: { id: id } });
                        return this.user(newUser)
                            .setEmail(email)
                            .setRefreshToken();
                    }
                    else {
                        if (user.getProvider().providerId === providerId) {
                            return user;
                        }
                        else {
                            throw new Error('auth/mismatch-provider');
                        }
                    }
                }
            }
            else {
                return null;
            }
        };
        AccountService.prototype.getPublicUsers = function (uids) {
            // turn string into string[]
            if (typeof uids === 'string') {
                uids = [uids];
            }
            // get profiles
            var profiles = {};
            for (var i = 0; i < uids.length; i++) {
                var uid = uids[i];
                profiles[uid] = this.getUser(uid).getPublicProfile();
            }
            return profiles;
        };
        AccountService.prototype.isValidPassword = function (password) {
            return password.length >= 7;
        };
        return AccountService;
    }());

    function idTokenMiddleware(Token) {
        return function (req, res, next) {
            var idToken = req.query['idToken'] || req.body['idToken'];
            if (!!idToken) {
                var auth = Token.decodeIdToken(idToken);
                if (!!auth) {
                    return next({ auth: auth });
                }
            }
            return res.error('auth/invalid-token');
        };
    }
    function userMiddleware(Account) {
        return function (req, res, next) {
            var idToken = req.query['idToken'] || req.body['idToken'];
            if (!!idToken) {
                var user = Account.getUserByIdToken(idToken);
                if (!!user) {
                    return next({ user: user });
                }
            }
            return res.error('auth/invalid-token');
        };
    }

    var ROUTING_ERRORS = {
        'auth/invalid-input': 'Invalid input.',
        'auth/invalid-token': 'Invalid token.',
        'auth/invalid-email': 'Invalid email.',
        'auth/invalid-password': 'Invalid password.',
        'auth/user-exists': 'User already exists.',
        'auth/user-not-exists': 'No user.'
    };
    function registerRoutes(Account, Oob) {
        return function (options) {
            var router = options.router, _a = options.endpoint, endpoint = _a === void 0 ? 'auth' : _a, _b = options.disabledRoutes, disabledRoutes = _b === void 0 ? [] : _b, _c = options.middlewares, middlewares = _c === void 0 ? [function (req, res, next) { return next(); }] : _c;
            // register errors & disabled routes
            router.setDisabled(disabledRoutes);
            router.setErrors(ROUTING_ERRORS);
            // user middleware
            var userMdlware = userMiddleware(Account);
            /**
             * public profiles
             */
            router.get.apply(router, ['/' + endpoint + '/public'].concat(middlewares, [function (req, res) {
                    var _a = req.query, uid = _a.uid, uids = _a.uids;
                    if (!uid && !uids) {
                        return res.error('auth/no-data');
                    }
                    var result;
                    try {
                        if (!!uid) {
                            var _b = uid, profile = Account.getPublicUsers(uid)[_b];
                            result = profile;
                        }
                        else {
                            result = Account.getPublicUsers(uids.split(',').filter(Boolean));
                        }
                    }
                    catch (error) {
                        return res.error(error);
                    }
                    return res.success(result);
                }]));
            /**
             * account
             */
            // create new
            router.put.apply(router, ['/' + endpoint].concat(middlewares, [function (req, res) {
                    var _a = req.body, _b = _a.email, email = _b === void 0 ? '' : _b, _c = _a.password, password = _c === void 0 ? '' : _c;
                    var user;
                    if (!email && !password) {
                        user = Account.getUserAnonymously();
                    }
                    else {
                        if (!isValidEmail(email)) {
                            return res.error('auth/invalid-email');
                        }
                        if (!Account.isValidPassword(password)) {
                            return res.error('auth/invalid-password');
                        }
                        user = Account.getUserByEmailAndPassword(email, password);
                    }
                    // user exists
                    var isNewUser = user.getInfo().isNewUser;
                    if (!isNewUser) {
                        return res.error('auth/user-exists');
                    }
                    // result
                    user.setlastLogin().save(); // update last login
                    var refreshToken = user.getData().refreshToken;
                    var response = {
                        info: user.getInfo(),
                        idToken: user.getIdToken(),
                        refreshToken: refreshToken
                    };
                    return res.success(response);
                }]));
            // login
            router.post.apply(router, ['/' + endpoint].concat(middlewares, [function (req, res) {
                    var _a = req.body, email = _a.email, _b = _a.password, password = _b === void 0 ? '' : _b, customToken = _a.customToken, _c = _a.offlineAccess, offlineAccess = _c === void 0 ? false : _c;
                    if (!email && !customToken) {
                        return res.error('auth/invalid-input');
                    }
                    // get user
                    var user;
                    if (!!customToken) {
                        user = Account.getUserByCustomToken(customToken);
                    }
                    else {
                        if (!isValidEmail(email)) {
                            return res.error('auth/invalid-email');
                        }
                        if (!Account.isValidPassword(password)) {
                            return res.error('auth/invalid-password');
                        }
                        user = Account.getUserByEmailAndPassword(email, password);
                    }
                    // no user
                    if (!user || user.getInfo().isNewUser) {
                        return res.error('auth/user-not-exists');
                    }
                    // result
                    user.setlastLogin().save(); // update last login
                    var response = {
                        info: user.getInfo(),
                        idToken: user.getIdToken()
                    };
                    if (!!offlineAccess) {
                        var refreshToken = user.getData().refreshToken;
                        response.refreshToken = refreshToken;
                    }
                    return res.success(response);
                }]));
            // logout (renew refresh token to revoke access)
            router["delete"].apply(router, ['/' + endpoint].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    user.setRefreshToken().save(); // new refresh token
                    return res.success({ acknowledged: true });
                }]));
            /**
             * cancel account
             */
            router["delete"].apply(router, ['/' + endpoint + '/cancel'].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    var refreshToken = req.body.refreshToken;
                    if (!!refreshToken) {
                        var userRefreshToken = user.getData().refreshToken;
                        if (refreshToken === userRefreshToken) {
                            user["delete"](); // delete
                            return res.success({ acknowledged: true });
                        }
                    }
                    return res.error('auth/invalid-input');
                }]));
            /**
             * user
             */
            // get info
            router.get.apply(router, ['/' + endpoint + '/user'].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    return res.success(user.getInfo());
                }]));
            // update profile (displayName, photoURL, ...)
            router.post.apply(router, ['/' + endpoint + '/user'].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    var profile = req.body.profile;
                    if (!!profile) {
                        return res.success(user.updateProfile(profile)
                            .save()
                            .getInfo());
                    }
                    return res.error('auth/invalid-input');
                }]));
            // set additional data
            router.post.apply(router, ['/' + endpoint + '/user/additional'].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    var additionalData = req.body.additionalData;
                    if (!!additionalData) {
                        return res.success(user.setAdditionalData(additionalData)
                            .save()
                            .getInfo());
                    }
                    return res.error('auth/invalid-input');
                }]));
            // set settings data
            router.post.apply(router, ['/' + endpoint + '/user/settings'].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    var settings = req.body.settings;
                    if (!!settings) {
                        return res.success(user.setSettings(settings)
                            .save()
                            .getInfo());
                    }
                    return res.error('auth/invalid-input');
                }]));
            // set publicly
            router.post.apply(router, ['/' + endpoint + '/user/publicly'].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    var publicly = req.body.publicly;
                    if (!!publicly) {
                        return res.success(user.setProfilePublicly(publicly)
                            .save()
                            .getInfo());
                    }
                    return res.error('auth/invalid-input');
                }]));
            // set privately
            router.post.apply(router, ['/' + endpoint + '/user/privately'].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    var privately = req.body.privately;
                    if (!!privately) {
                        return res.success(user.setProfilePrivately(privately)
                            .save()
                            .getInfo());
                    }
                    return res.error('auth/invalid-input');
                }]));
            // update username
            router.post.apply(router, ['/' + endpoint + '/user/username'].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    var username = req.body.username;
                    // TODO: must not contains invalid characters
                    // username must be unique
                    if (!!username && !Account.isUser({ username: username })) {
                        return res.success(user.setUsername(username)
                            .save()
                            .getInfo());
                    }
                    return res.error('auth/invalid-input');
                }]));
            // update password
            router.post.apply(router, ['/' + endpoint + '/user/password'].concat(middlewares, [userMdlware,
                function (req, res) {
                    var user = req.data.user;
                    var _a = req.body, currentPassword = _a.currentPassword, newPassword = _a.newPassword;
                    if (!!currentPassword &&
                        !!newPassword &&
                        !!Account.isValidPassword(newPassword) &&
                        !!user.comparePassword(currentPassword)) {
                        return res.success(user.setPassword(newPassword)
                            .save()
                            .getInfo());
                    }
                    return res.error('auth/invalid-input');
                }]));
            // TODO: update email
            // TODO: update phoneNumber
            // TODO: update claims (or edit from spreadsheet)
            // TODO: may add signInWithPopup
            // TODO: may add signInWithEmailLink
            /**
             * token
             */
            // exchange the refresh token for a new id token
            router.get.apply(router, ['/' + endpoint + '/token'].concat(middlewares, [function (req, res) {
                    var _a = req.query, refreshToken = _a.refreshToken, _b = _a.type, type = _b === void 0 ? 'ID' : _b;
                    if (!!refreshToken) {
                        var user = Account.getUserByRefreshToken(refreshToken);
                        // no user
                        if (!!user) {
                            var response = void 0;
                            if (type === 'ID') {
                                response = { idToken: user.getIdToken() };
                            }
                            return res.success(response);
                        }
                    }
                    return res.error('auth/invalid-input');
                }]));
            /**
             * oob
             */
            // request emails
            router.put.apply(router, ['/' + endpoint + '/oob'].concat(middlewares, [function (req, res) {
                    var _a = req.body, mode = _a.mode, email = _a.email;
                    if (!!mode && !!email) {
                        var user = Account.getUser({ email: email });
                        if (!!user) {
                            if (mode === 'resetPassword') {
                                Oob.sendPasswordResetEmail(user.setOob(mode)
                                    .save()
                                    .getData());
                            }
                            else if (mode === 'verifyEmail') {
                                Oob.sendEmailVerificationEmail(user.setOob(mode)
                                    .save()
                                    .getData());
                            }
                        }
                    }
                    return res.success({ acknowledged: true });
                }]));
            // check oob code
            router.get.apply(router, ['/' + endpoint + '/oob'].concat(middlewares, [function (req, res) {
                    var _a = req.query, oobCode = _a.oobCode, mode = _a.mode;
                    if (!!oobCode) {
                        var user = Account.getUserByOobCode(oobCode);
                        var _b = !!user ? user.getData() : {}, email = _b.email, oobMode = _b.oobMode;
                        if (!!user && (!mode || (!!mode && mode === oobMode))) {
                            var operations = {
                                resetPassword: 'PASSWORD_RESET',
                                verifyEmail: 'VERIFY_EMAIL'
                            };
                            return res.success({
                                operation: operations[oobMode] || 'NONE',
                                data: { email: email }
                            });
                        }
                    }
                    return res.error('auth/invalid-input');
                }]));
            // handler
            router.post.apply(router, ['/' + endpoint + '/oob'].concat(middlewares, [function (req, res) {
                    var _a = req.body, mode = _a.mode, oobCode = _a.oobCode;
                    if (!!mode && !!oobCode) {
                        var user = Account.getUserByOobCode(oobCode);
                        var oobMode = (!!user ? user.getData() : {}).oobMode;
                        if (!!user && mode === oobMode) {
                            // reset password
                            if (mode === 'resetPassword') {
                                var _b = req.body.newPassword, newPassword = _b === void 0 ? '' : _b;
                                if (Account.isValidPassword(newPassword)) { // validate password
                                    user.setPassword(newPassword)
                                        .setRefreshToken() // revoke current access
                                        .setOob() // revoke oob code
                                        .save();
                                    return res.success({ acknowledged: true });
                                }
                            }
                            // verify email
                            else if (mode === 'verifyEmail') {
                                user.confirmEmail()
                                    .save();
                                return res.success({ acknowledged: true });
                            }
                        }
                    }
                    return res.error('auth/invalid-input');
                }]));
            /**
             * default auth actions
             */
            // facing page
            router.get.apply(router, ['/' + endpoint + '/action'].concat(middlewares, [function (req, res) {
                    var _a = req.query, mode = _a.mode, oobCode = _a.oobCode;
                    if (!!mode && !!oobCode) {
                        var user = Account.getUserByOobCode(oobCode);
                        var _b = !!user ? user.getData() : {}, email = _b.email, oobMode = _b.oobMode;
                        if (!!user && mode === oobMode) {
                            // reset password
                            if (mode === 'resetPassword') {
                                var url = Oob.buildAuthUrl(mode, oobCode);
                                return res.html(htmlPage("<style>\n                .form input {\n                  display: block;\n                  width: 100%;\n                  max-width: 300px;\n                  padding: .25rem;\n                  border-radius: .25rem;\n                  margin: 1rem 0 0;\n                }\n                .form button {\n                  display: block;\n                  padding: .25rem;\n                  border-radius: .25rem;\n                  margin-top: 1rem;\n                }\n                .message {\n                  max-width: 300px;\n                  border: 1px solid black;\n                  padding: .5rem;\n                  border-radius: .25rem;\n                  margin-top: 1rem;\n                }\n                .message.error {\n                  border: 1px solid red;\n                  color: red;\n                }\n                .message.success {\n                  border: 1px solid green;\n                  color: green;\n                }\n              </style>\n\n              <div id=\"app\">\n                <h1>Reset password</h1>\n                <p>Reset your acccount password of <strong>" + email + "</strong>:</p>\n                <div class=\"form\">\n                  <input type=\"password\" placeholder=\"New password\" v-model=\"password\" />\n                  <input type=\"password\" placeholder=\"Repeat password\" v-model=\"passwordConfirm\" />\n                  <button v-on:click=\"resetPassword\">Reset password</button>\n                </div>\n                <div class=\"message\" v-bind:class=\"[messageClass]\" v-if=\"message\">{{ message }}</div>\n              </div>\n\n              <script src=\"https://cdn.jsdelivr.net/npm/vue\"></script>\n              <script>\n                var app = new Vue({\n                  el: '#app',\n                  data: {\n                    password: '',\n                    passwordConfirm: '',\n                    message: '',\n                    messageClass: ''\n                  },\n                  methods: {\n                    resetPassword: async function () {\n                      this.message = ''; // reset message\n                      if (!this.password || this.password !== this.passwordConfirm) {\n                        this.messageClass = 'error';\n                        return this.message = 'Password mismatch!';\n                      }\n                      var response = await fetch('" + url + "', {\n                        method: 'POST',\n                        body: JSON.stringify({\n                          mode: '" + mode + "',\n                          oobCode: '" + oobCode + "',\n                          newPassword: this.password,\n                        }),\n                        headers: {\n                          'Content-Type': 'application/x-www-form-urlencoded',\n                        },\n                      });\n                      if (!response.ok) {\n                        this.messageClass = 'error';\n                        return this.message = 'Request failed.';\n                      }\n                      var result = await response.json();\n                      if (result.error) {\n                        this.messageClass = 'error';\n                        return this.message = result.message;\n                      } else {\n                        this.messageClass = 'success';\n                        return this.message = result.data.message;\n                      }\n                    }\n                  }\n                })\n              </script>"));
                            }
                            // verify email
                            else if (mode === 'verifyEmail') {
                                // verify the email
                                user.confirmEmail()
                                    .save();
                                return res.html(htmlPage("<h1>Email confirmed</h1>\n              <p>Your account email is now verified.</p>"));
                            }
                        }
                    }
                    return res.html(htmlPage("<h1>Action failed</h1>\n        <p>Invalid input.</p>"));
                }]));
            // handler
            router.post.apply(router, ['/' + endpoint + '/action'].concat(middlewares, [function (req, res) {
                    var _a = req.body, mode = _a.mode, oobCode = _a.oobCode;
                    if (!!mode && !!oobCode) {
                        var user = Account.getUserByOobCode(oobCode);
                        var oobMode = (!!user ? user.getData() : {}).oobMode;
                        if (!!user && mode === oobMode) {
                            // reset password
                            if (mode === 'resetPassword') {
                                var _b = req.body.newPassword, newPassword = _b === void 0 ? '' : _b;
                                if (Account.isValidPassword(newPassword)) { // validate password
                                    user.setPassword(newPassword)
                                        .setRefreshToken() // revoke current access
                                        .setOob() // revoke oob code
                                        .save();
                                    return res.success({
                                        message: 'Your password has been updated, now you can login with new password.'
                                    });
                                }
                            }
                        }
                    }
                    return res.error('Action failed, invalid input.');
                }]));
            /**
             * oauth
             */
            router.get.apply(router, ['/' + endpoint + '/oauth'].concat(middlewares, [function (req, res) {
                    var _a = req.query, providerId = _a.providerId, accessToken = _a.accessToken;
                    if (!providerId || !accessToken) {
                        return res.error('auth/no-data');
                    }
                    var result;
                    try {
                        var user = Account.getUserByOauthProvider(providerId, accessToken);
                        // result
                        user.setlastLogin().save(); // update last login
                        var refreshToken = user.getData().refreshToken;
                        result = {
                            info: user.getInfo(),
                            idToken: user.getIdToken(),
                            refreshToken: refreshToken
                        };
                    }
                    catch (error) {
                        return res.error(error);
                    }
                    return res.success(result);
                }]));
        };
    }
    function htmlPage(body) {
        return ("<!DOCTYPE html>\n    <html lang=\"en\">\n    <head>\n      <meta charset=\"UTF-8\">\n      <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n      <meta http-equiv=\"X-UA-Compatible\" content=\"ie=edge\">\n      <title>Sheetbase</title>\n\n      <style>\n        body {\n          font-family: Arial, Helvetica, sans-serif;\n        }\n        .wrapper {\n          width: 500px;\n          margin: 100px auto;\n        }\n      </style>\n\n    </head>\n    <body>\n\n      <div class=\"wrapper\">\n        " + body + "\n      <div>\n\n    </body>\n    </html>");
    }

    function auth(options) {
        var Account = new AccountService(options);
        var Oob = new OobService(options);
        var Token = new TokenService(options);
        return {
            Oob: Oob,
            Token: Token,
            Account: Account,
            IdTokenMiddleware: idTokenMiddleware(Token),
            UserMiddleware: userMiddleware(Account),
            registerRoutes: registerRoutes(Account, Oob)
        };
    }
    function sheetsDriver(Sheets) {
        return new SheetsDriver(Sheets);
    }

    /*
    * Add integers, wrapping at 2^32. This uses 16-bit operations internally
    * to work around bugs in some JS interpreters.
    */
    function safeAdd(x, y) {
        var lsw = (x & 0xffff) + (y & 0xffff);
        var msw = (x >> 16) + (y >> 16) + (lsw >> 16);
        return (msw << 16) | (lsw & 0xffff);
    }
    /*
    * Bitwise rotate a 32-bit number to the left.
    */
    function bitRotateLeft(num, cnt) {
        return (num << cnt) | (num >>> (32 - cnt));
    }
    /*
    * These functions implement the four basic operations the algorithm uses.
    */
    function md5cmn(q, a, b, x, s, t) {
        return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b);
    }
    function md5ff(a, b, c, d, x, s, t) {
        return md5cmn((b & c) | (~b & d), a, b, x, s, t);
    }
    function md5gg(a, b, c, d, x, s, t) {
        return md5cmn((b & d) | (c & ~d), a, b, x, s, t);
    }
    function md5hh(a, b, c, d, x, s, t) {
        return md5cmn(b ^ c ^ d, a, b, x, s, t);
    }
    function md5ii(a, b, c, d, x, s, t) {
        return md5cmn(c ^ (b | ~d), a, b, x, s, t);
    }
    /*
    * Calculate the MD5 of an array of little-endian words, and a bit length.
    */
    function binlMD5(x, len) {
        /* append padding */
        x[len >> 5] |= 0x80 << (len % 32);
        x[((len + 64) >>> 9 << 4) + 14] = len;
        var i;
        var olda;
        var oldb;
        var oldc;
        var oldd;
        var a = 1732584193;
        var b = -271733879;
        var c = -1732584194;
        var d = 271733878;
        for (i = 0; i < x.length; i += 16) {
            olda = a;
            oldb = b;
            oldc = c;
            oldd = d;
            a = md5ff(a, b, c, d, x[i], 7, -680876936);
            d = md5ff(d, a, b, c, x[i + 1], 12, -389564586);
            c = md5ff(c, d, a, b, x[i + 2], 17, 606105819);
            b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330);
            a = md5ff(a, b, c, d, x[i + 4], 7, -176418897);
            d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426);
            c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341);
            b = md5ff(b, c, d, a, x[i + 7], 22, -45705983);
            a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416);
            d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417);
            c = md5ff(c, d, a, b, x[i + 10], 17, -42063);
            b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162);
            a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682);
            d = md5ff(d, a, b, c, x[i + 13], 12, -40341101);
            c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290);
            b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329);
            a = md5gg(a, b, c, d, x[i + 1], 5, -165796510);
            d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632);
            c = md5gg(c, d, a, b, x[i + 11], 14, 643717713);
            b = md5gg(b, c, d, a, x[i], 20, -373897302);
            a = md5gg(a, b, c, d, x[i + 5], 5, -701558691);
            d = md5gg(d, a, b, c, x[i + 10], 9, 38016083);
            c = md5gg(c, d, a, b, x[i + 15], 14, -660478335);
            b = md5gg(b, c, d, a, x[i + 4], 20, -405537848);
            a = md5gg(a, b, c, d, x[i + 9], 5, 568446438);
            d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690);
            c = md5gg(c, d, a, b, x[i + 3], 14, -187363961);
            b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501);
            a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467);
            d = md5gg(d, a, b, c, x[i + 2], 9, -51403784);
            c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473);
            b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734);
            a = md5hh(a, b, c, d, x[i + 5], 4, -378558);
            d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463);
            c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562);
            b = md5hh(b, c, d, a, x[i + 14], 23, -35309556);
            a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060);
            d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353);
            c = md5hh(c, d, a, b, x[i + 7], 16, -155497632);
            b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640);
            a = md5hh(a, b, c, d, x[i + 13], 4, 681279174);
            d = md5hh(d, a, b, c, x[i], 11, -358537222);
            c = md5hh(c, d, a, b, x[i + 3], 16, -722521979);
            b = md5hh(b, c, d, a, x[i + 6], 23, 76029189);
            a = md5hh(a, b, c, d, x[i + 9], 4, -640364487);
            d = md5hh(d, a, b, c, x[i + 12], 11, -421815835);
            c = md5hh(c, d, a, b, x[i + 15], 16, 530742520);
            b = md5hh(b, c, d, a, x[i + 2], 23, -995338651);
            a = md5ii(a, b, c, d, x[i], 6, -198630844);
            d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415);
            c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905);
            b = md5ii(b, c, d, a, x[i + 5], 21, -57434055);
            a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571);
            d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606);
            c = md5ii(c, d, a, b, x[i + 10], 15, -1051523);
            b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799);
            a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359);
            d = md5ii(d, a, b, c, x[i + 15], 10, -30611744);
            c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380);
            b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649);
            a = md5ii(a, b, c, d, x[i + 4], 6, -145523070);
            d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379);
            c = md5ii(c, d, a, b, x[i + 2], 15, 718787259);
            b = md5ii(b, c, d, a, x[i + 9], 21, -343485551);
            a = safeAdd(a, olda);
            b = safeAdd(b, oldb);
            c = safeAdd(c, oldc);
            d = safeAdd(d, oldd);
        }
        return [a, b, c, d];
    }
    /*
    * Convert an array of little-endian words to a string
    */
    function binl2rstr(input) {
        var i;
        var output = '';
        var length32 = input.length * 32;
        for (i = 0; i < length32; i += 8) {
            output += String.fromCharCode((input[i >> 5] >>> (i % 32)) & 0xff);
        }
        return output;
    }
    /*
    * Convert a raw string to an array of little-endian words
    * Characters >255 have their high-byte silently ignored.
    */
    function rstr2binl(input) {
        var i;
        var output = [];
        output[(input.length >> 2) - 1] = undefined;
        for (i = 0; i < output.length; i += 1) {
            output[i] = 0;
        }
        var length8 = input.length * 8;
        for (i = 0; i < length8; i += 8) {
            output[i >> 5] |= (input.charCodeAt(i / 8) & 0xff) << (i % 32);
        }
        return output;
    }
    /*
    * Calculate the MD5 of a raw string
    */
    function rstrMD5(s) {
        return binl2rstr(binlMD5(rstr2binl(s), s.length * 8));
    }
    /*
    * Calculate the HMAC-MD5, of a key and some data (raw strings)
    */
    function rstrHMACMD5(key, data) {
        var i;
        var bkey = rstr2binl(key);
        var ipad = [];
        var opad = [];
        var hash;
        ipad[15] = opad[15] = undefined;
        if (bkey.length > 16) {
            bkey = binlMD5(bkey, key.length * 8);
        }
        for (i = 0; i < 16; i += 1) {
            ipad[i] = bkey[i] ^ 0x36363636;
            opad[i] = bkey[i] ^ 0x5c5c5c5c;
        }
        hash = binlMD5(ipad.concat(rstr2binl(data)), 512 + data.length * 8);
        return binl2rstr(binlMD5(opad.concat(hash), 512 + 128));
    }
    /*
    * Convert a raw string to a hex string
    */
    function rstr2hex(input) {
        var hexTab = '0123456789abcdef';
        var output = '';
        var x;
        var i;
        for (i = 0; i < input.length; i += 1) {
            x = input.charCodeAt(i);
            output += hexTab.charAt((x >>> 4) & 0x0f) + hexTab.charAt(x & 0x0f);
        }
        return output;
    }
    /*
    * Encode a string as utf-8
    */
    function str2rstrUTF8(input) {
        return unescape(encodeURIComponent(input));
    }
    /*
    * Take string arguments and return either raw or hex encoded strings
    */
    function rawMD5(s) {
        return rstrMD5(str2rstrUTF8(s));
    }
    function hexMD5(s) {
        return rstr2hex(rawMD5(s));
    }
    function rawHMACMD5(k, d) {
        return rstrHMACMD5(str2rstrUTF8(k), str2rstrUTF8(d));
    }
    function hexHMACMD5(k, d) {
        return rstr2hex(rawHMACMD5(k, d));
    }
    function md5(str, key, raw) {
        if (raw === void 0) { raw = false; }
        if (!key) {
            if (!raw) {
                return hexMD5(str);
            }
            return rawMD5(str);
        }
        if (!raw) {
            return hexHMACMD5(key, str);
        }
        return rawHMACMD5(key, str);
    }

    var __assign = function () {
        __assign = Object.assign || function(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                    t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    var DriveService = /** @class */ (function () {
        function DriveService(options) {
            this.errors = {
                'file/no-file': 'File not found (no VIEW permission or trashed).',
                'file/no-edit': 'No EDIT permission.',
                'file/invalid-upload': 'Invalid upload resource.',
                'file/invalid-size': 'The file is too big.',
                'file/invalid-type': 'The file format is not supported.'
            };
            this.req = null;
            this.auth = null;
            // for viewing the file only
            // PUBLIC: anyone
            // PRIVATE:
            // only me (the developer)
            // and the uploader (if users login with their Google email)
            this.sharingPresets = {
                PUBLIC: { access: 'ANYONE_WITH_LINK', permission: 'VIEW' },
                PRIVATE: { access: 'PRIVATE', permission: 'VIEW' }
            };
            this.options = __assign({ maxSize: 10, urlBuilder: ['https://drive.google.com/uc?id='] }, options);
        }
        DriveService.prototype.setIntegration = function (key, value) {
            this.options[key] = value;
            return this;
        };
        DriveService.prototype.setRequest = function (request) {
            // req object
            this.req = request;
            // auth object
            var AuthToken = this.options.AuthToken;
            var idToken = !!request ? (request.query['idToken'] || request.body['idToken']) : null;
            if (!!idToken && !!AuthToken) {
                this.auth = AuthToken.decodeIdToken(idToken);
            }
        };
        /**
         * routes
         */
        DriveService.prototype.registerRoutes = function (options) {
            var _this = this;
            var router = options.router, _a = options.endpoint, endpoint = _a === void 0 ? 'storage' : _a, _b = options.disabledRoutes, disabledRoutes = _b === void 0 ? [
                'post:/' + endpoint,
                'put:/' + endpoint,
                'delete:/' + endpoint,
            ] : _b, _c = options.middlewares, middlewares = _c === void 0 ? [function (req, res, next) { return next(); }] : _c;
            // register errors & disabled routes
            router.setDisabled(disabledRoutes);
            router.setErrors(this.errors);
            // register request for security
            middlewares.push(function (req, res, next) {
                _this.setRequest(req);
                return next();
            });
            // get file information
            router.get.apply(router, ['/' + endpoint].concat(middlewares, [function (req, res) {
                    var id = req.query.id;
                    // process
                    var result;
                    try {
                        result = _this.getFileInfoById(id);
                    }
                    catch (code) {
                        return res.error(code);
                    }
                    // succeed
                    return res.success(result);
                }]));
            // upload a file / multiple files
            router.put.apply(router, ['/' + endpoint].concat(middlewares, [function (req, res) {
                    var _a = req.body, 
                    // single file
                    fileData = _a.file, customFolder = _a.folder, renamePolicy = _a.rename, sharing = _a.share, 
                    // multiple files
                    uploadResources = _a.files;
                    // process
                    var result;
                    try {
                        if (!!fileData &&
                            !uploadResources) {
                            // single file
                            var file = _this.uploadFile(fileData, customFolder, renamePolicy, sharing);
                            result = _this.getFileInfo(file);
                        }
                        else if (!!uploadResources &&
                            uploadResources.length <= 30) {
                            // multiple files
                            var files = _this.uploadFiles(uploadResources);
                            result = _this.getFilesInfo(files);
                        }
                    }
                    catch (code) {
                        return res.error(code);
                    }
                    // succeed
                    return res.success(result);
                }]));
            // update a file
            router.post.apply(router, ['/' + endpoint].concat(middlewares, [function (req, res) {
                    var _a = req.body, id = _a.id, data = _a.data;
                    // process
                    try {
                        _this.updateFile(id, data);
                    }
                    catch (code) {
                        return res.error(code);
                    }
                    // succeed
                    return res.success({ done: true });
                }]));
            // delete a file
            router["delete"].apply(router, ['/' + endpoint].concat(middlewares, [function (req, res) {
                    var id = req.body.id;
                    // process
                    try {
                        _this.removeFile(id);
                    }
                    catch (code) {
                        return res.error(code);
                    }
                    // succeed
                    return res.success({ done: true });
                }]));
        };
        /**
         * helpers
         */
        DriveService.prototype.base64Parser = function (base64Value) {
            var _a = base64Value.split(';base64,'), header = _a[0], body = _a[1];
            var mimeType = header.replace('data:', '');
            if (!mimeType || !body) {
                throw new Error('Malform base64 data.');
            }
            var size = body.replace(/\=/g, '').length * 0.75; // bytes
            return { mimeType: mimeType, size: size, base64Body: body };
        };
        DriveService.prototype.isFileInsideUploadFolder = function (file) {
            var parentIds = [];
            var parents = file.getParents();
            while (parents.hasNext()) {
                parentIds.push(parents.next().getId());
            }
            return (parentIds.indexOf(this.options.uploadFolder) > -1);
        };
        DriveService.prototype.isFileShared = function (file) {
            var access = file.getSharingAccess();
            return (access === DriveApp.Access.ANYONE ||
                access === DriveApp.Access.ANYONE_WITH_LINK);
        };
        DriveService.prototype.isValidFileType = function (mimeType) {
            var allowTypes = this.options.allowTypes;
            return !allowTypes || allowTypes.indexOf(mimeType) > -1;
        };
        DriveService.prototype.isValidFileSize = function (sizeBytes) {
            var maxSize = this.options.maxSize;
            var sizeMB = sizeBytes / 1000000;
            return !maxSize || maxSize === 0 || sizeMB <= maxSize;
        };
        DriveService.prototype.getSharingPreset = function (preset) {
            return this.sharingPresets[preset];
        };
        DriveService.prototype.generateFileName = function (fileName, rename) {
            var fileNameArr = fileName.split('.');
            // extract name & extension
            var ext = fileNameArr.pop();
            var name = fileNameArr.join('.');
            // rename
            if (!!rename) {
                if (rename === 'AUTO') {
                    name = Utilities.getUuid();
                }
                if (rename === 'HASH') {
                    name = md5(fileName);
                }
            }
            return name + '.' + ext;
        };
        DriveService.prototype.buildFileUrl = function (id) {
            var urlBuilder = this.options.urlBuilder;
            var builder = (urlBuilder instanceof Array) ?
                function (id) { return (urlBuilder[0] + id + (urlBuilder[1] || '')); } : urlBuilder;
            return builder(id);
        };
        DriveService.prototype.getFileInfo = function (file) {
            var fileId = file.getId();
            var name = file.getName();
            var mimeType = file.getMimeType();
            var description = file.getDescription();
            var size = file.getSize();
            var link = file.getUrl();
            var url = this.buildFileUrl(fileId);
            return {
                id: fileId,
                name: name,
                mimeType: mimeType,
                description: description,
                size: size,
                link: link,
                url: url,
                downloadUrl: url + '&export=download'
            };
        };
        DriveService.prototype.getFilesInfo = function (files) {
            var info = [];
            for (var i = 0; i < files.length; i++) {
                info.push(this.getFileInfo(files[i]));
            }
            return info;
        };
        DriveService.prototype.getUploadFolder = function () {
            var uploadFolder = this.options.uploadFolder;
            return DriveApp.getFolderById(uploadFolder);
        };
        DriveService.prototype.getOrCreateFolderByName = function (name, parentFolder) {
            var folder = parentFolder || this.getUploadFolder();
            // get all children
            var childFolders = folder.getFoldersByName(name);
            // return the first or create new one
            if (!childFolders.hasNext()) {
                folder = folder.createFolder(name);
            }
            else {
                folder = childFolders.next();
            }
            return folder;
        };
        DriveService.prototype.createFolderByYearAndMonth = function (parentFolder) {
            var date = new Date();
            var yearStr = '' + date.getFullYear();
            var monthStr = date.getMonth() + 1;
            monthStr = '' + (monthStr < 10 ? '0' + monthStr : monthStr);
            var folder = this.getOrCreateFolderByName(yearStr, parentFolder);
            return this.getOrCreateFolderByName(monthStr, folder);
        };
        DriveService.prototype.createFileFromBase64Body = function (parentFolder, fileName, mimeType, base64Body) {
            var data = Utilities.base64Decode(base64Body, Utilities.Charset.UTF_8);
            var blob = Utilities.newBlob(data, mimeType, fileName);
            return parentFolder.createFile(blob);
        };
        DriveService.prototype.setFileSharing = function (file, sharing) {
            if (sharing === void 0) { sharing = 'PRIVATE'; }
            var _a = (typeof sharing === 'string') ? this.getSharingPreset(sharing) : sharing, _b = _a.access, access = _b === void 0 ? 'PRIVATE' : _b, _c = _a.permission, permission = _c === void 0 ? 'VIEW' : _c;
            return file.setSharing(DriveApp.Access[access.toUpperCase()], DriveApp.Permission[permission.toUpperCase()]);
        };
        DriveService.prototype.setEditPermissionForUser = function (file, auth) {
            if (!!auth && !!auth.email) {
                file.addEditors([auth.email]);
            }
            return file;
        };
        /**
         * security checker
         */
        DriveService.prototype.hasViewPermission = function (file) {
            return (this.isFileShared(file) || // shared publicly
                this.hasEditPermission(file) // for logged in user
            );
        };
        DriveService.prototype.hasEditPermission = function (file) {
            var email = (this.auth || {}).email;
            return (!!email &&
                file.getAccess(email) === DriveApp.Permission.EDIT);
        };
        /**
         * main
         */
        DriveService.prototype.getFileById = function (id) {
            var file = DriveApp.getFileById(id);
            if (file.isTrashed() || // file in the trash
                !this.hasViewPermission(file) // no view permission
            ) {
                throw new Error('file/no-file');
            }
            return file;
        };
        DriveService.prototype.getFileInfoById = function (id) {
            return this.getFileInfo(this.getFileById(id));
        };
        DriveService.prototype.uploadFile = function (fileData, customFolder, renamePolicy, sharing) {
            if (sharing === void 0) { sharing = 'PRIVATE'; }
            // check input data
            if (!fileData ||
                !fileData.base64Value ||
                !fileData.name) {
                throw new Error('file/invalid-upload');
            }
            // retrieve data
            var name = fileData.name, base64Value = fileData.base64Value;
            var _a = this.base64Parser(base64Value), mimeType = _a.mimeType, size = _a.size, base64Body = _a.base64Body;
            // check input file
            if (!this.isValidFileType(mimeType)) {
                throw new Error('file/invalid-type');
            }
            if (!this.isValidFileSize(size)) {
                throw new Error('file/invalid-size');
            }
            // get the upload folder
            var folder = this.getUploadFolder();
            if (customFolder) {
                folder = this.getOrCreateFolderByName(customFolder, folder);
            }
            else if (!!this.options.nested) {
                folder = this.createFolderByYearAndMonth(folder);
            }
            // save the file
            var fileName = this.generateFileName(name, renamePolicy);
            var file = this.createFileFromBase64Body(folder, fileName, mimeType, base64Body);
            // set sharing
            this.setFileSharing(file, sharing);
            // set edit security
            this.setEditPermissionForUser(file, this.auth);
            // return
            return file;
        };
        DriveService.prototype.uploadFiles = function (uploadResources) {
            var files = [];
            for (var i = 0; i < uploadResources.length; i++) {
                // upload a file
                var _a = uploadResources[i], fileData = _a.file, customFolder = _a.folder, renamePolicy = _a.rename, sharing = _a.share;
                var file = this.uploadFile(fileData, customFolder, renamePolicy, sharing);
                // save to return
                files.push(file);
            }
            return files;
        };
        DriveService.prototype.updateFile = function (id, data) {
            if (data === void 0) { data = {}; }
            var file = this.getFileById(id);
            if (!this.hasEditPermission(file)) {
                throw new Error('file/no-edit');
            }
            // update data
            var name = data.name, description = data.description, content = data.content, sharing = data.sharing;
            if (!!name) {
                file.setName(name);
            }
            if (!!description) {
                file.setDescription(description);
            }
            if (!!content) {
                file.setContent(content);
            }
            if (!!sharing) {
                file = this.setFileSharing(file, sharing);
            }
            return file;
        };
        DriveService.prototype.removeFile = function (id) {
            var file = this.getFileById(id);
            if (!this.hasEditPermission(file)) {
                throw new Error('file/no-edit');
            }
            return file.setTrashed(true);
        };
        return DriveService;
    }());

    function drive(options) {
        return new DriveService(options);
    }

    // Please do NOT edit this file directlly
    // To synchronize set/update project configs:
    // + From terminal, run $ sheetbase config set key=value|...
    // + Or, edit configs in sheetbase.json, then run $ sheetbase config update
    var SHEETBASE_CONFIG = {
        "apiKey": "RU2h6FREPlzoZo2Itha28uG5toGAk78U",
        "databaseId": "11Owi30p-FHIMH7Z44LUmA0KYiYCkMdUGBS_iApBf_rg",
        "uploadFolder": "1FdFxnbYhn_fx2AnFpenc5QVlR8TUwCUf"
    };

    function MessageTemplating(_a) {
        var item = _a.item;
        var displayName = item.displayName, email = item.email, content = item.content;
        return ("\n    <p>Hello" + (!!displayName ? (' ' + displayName) : '') + ",</p>\n    <p>We recieved your contact message, will reply soon!</p>\n    <p><strong>Contact info:</strong></p>\n    <ul>\n      <li>Name: <strong>" + (displayName || 'n/a') + "</strong></li>\n      <li>Email: <strong>" + email + "</strong></li>\n    </ul>\n    <p><strong>Detail:</strong></p>\n    <p>" + content.replace(/(?:\r\n|\r|\n)/g, '<br />') + "</p>\n  ");
    }

    var currencyCode = '$';
    var supportPhone = '0123456789';
    var supportEmail = 'contact@sheetbase.dev';
    // tslint:disable:max-line-length
    function OrderTemplating(_a) {
        var host = _a.host, item = _a.item;
        var productList = '';
        var i = 0;
        for (var _i = 0, _b = Object.keys(item.items); _i < _b.length; _i++) {
            var key = _b[_i];
            var _c = item.items[key], product = _c.product, qty = _c.qty;
            i++;
            var productUrl = host + '/product/' + product._id;
            productList += ("\n      <tr>\n        <td style=\"text-align: center;\">" + i + "</td>\n        <td style=\"width: 15%;\">\n          <a href=\"" + productUrl + "\" target=\"_blank\"><img style=\"width: 80%; border-radius: 10px;\" src=\"" + product.thumbnail + "\" alt=\"" + product.title + "\" /></a>\n        </td>\n        <td>\n          <p><a href=\"" + productUrl + "\" target=\"_blank\"><strong>" + product.title + "</strong></a></p>\n          <p><em>" + product.sku + "</em></p>\n        </td>\n        <td style=\"text-align: center;\">" + product.price + " <em>(" + product.unit + ")</em></td>\n        <td style=\"text-align: center;\">" + qty + "</td>\n        <td style=\"text-align: center;\">" + product.price * qty + "</td>\n      </tr>\n    ");
        }
        return ("\n    <p>Hello!</p>\n    <p>We received your order, will process and contact you soon, please wait for our next email. Thank you for using our service!</p>\n\n    <p><strong>Order detail:</strong></p>\n    <ul>\n      <li>Ref: <strong>" + item.$key + "</strong></li>\n      <li>Subtotal: " + item.subtotal + "</li>\n      <li>Discount: " + item.discountTotal + "</li>\n      <li>Total: <strong>" + item.total + "</strong> <em>" + currencyCode + "</em></li>\n    </ul>\n\n    <table style=\"width: 100%; max-width: 768px;\">\n      <tr style=\"background: #EEE;\">\n        <th>#</th>\n        <th style=\"width: 50%;\" colspan=\"2\">Product</th>\n        <th>Price</th>\n        <th>Qty</th>\n        <th>Total</th>\n      </tr>\n      " + productList + "\n    </table>\n\n    <p>For supporting, please contact us:</p>\n    <ul>\n      <li>Phone: <a href=\"tel:" + supportPhone + "\">" + supportPhone + "</a></li>\n      <li>Email: <a href=\"mailto:" + supportEmail + "\">" + supportEmail + "</a></li>\n    </ul>\n    <p>Thank you!</p>\n  ");
    }

    var appRoutes = (function () {
        var router = Sheetbase.Router;
        router.get('/', function (req, res) {
            return res.html("<h1>Sheetbase Backend</h1>");
        });
        router.post('/', function (req, res) {
            return res.success({ title: 'Sheetbase Backend' });
        });
    });

    // configs
    var apiKey = SHEETBASE_CONFIG.apiKey, databaseId = SHEETBASE_CONFIG.databaseId, uploadFolder = SHEETBASE_CONFIG.uploadFolder;
    /**
     * modules
     */
    var Sheetbase = sheetbase({
        allowMethodsWhenDoGet: true
    });
    var ApiKeyMiddleware = middleware({ key: apiKey });
    var Sheets = sheets({
        databaseId: databaseId,
        security: true
    });
    var Gmail = gmail({
        prefix: 'Sheetbase',
        categories: {
            message: 'Messages',
            order: 'Orders'
        },
        templates: {
            message: MessageTemplating,
            order: OrderTemplating
        }
    });
    var Auth = auth({
        encryptionSecret: 'secret',
        databaseDriver: sheetsDriver(Sheets.toAdmin()),
        authUrl: function (mode, oobCode) { return ScriptApp.getService().getUrl() +
            '?e=auth/action&' +
            ("key=" + apiKey + "&mode=" + mode + "&oobCode=" + oobCode); }
    });
    var Drive = drive({ uploadFolder: uploadFolder });
    /**
     * routes
     */
    Sheets
        .registerRoutes({
        router: Sheetbase.Router,
        middlewares: [ApiKeyMiddleware],
        disabledRoutes: []
    });
    Auth
        .registerRoutes({
        router: Sheetbase.Router,
        middlewares: [ApiKeyMiddleware],
        disabledRoutes: []
    });
    Drive
        .registerRoutes({
        router: Sheetbase.Router,
        middlewares: [ApiKeyMiddleware],
        disabledRoutes: []
    });
    appRoutes();

    exports.ApiKeyMiddleware = ApiKeyMiddleware;
    exports.Auth = Auth;
    exports.Drive = Drive;
    exports.Gmail = Gmail;
    exports.Sheetbase = Sheetbase;
    exports.Sheets = Sheets;

    Object.defineProperty(exports, '__esModule', { value: true });

}));

function doGet(e) { return App.Sheetbase.HTTP.get(e); }
function doPost(e) { return App.Sheetbase.HTTP.post(e); }